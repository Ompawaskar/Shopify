import streamlit as st
import requests
import uuid
from typing import Optional

API_BASE = "http://localhost:8000"

st.set_page_config(
    page_title="TrustShop — Shopping Intelligence",
    page_icon="◈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Design System ──────────────────────────────────────────────────────────────
# Aesthetic: Dark Intelligence Terminal
# Fonts: Space Mono (terminal/data) + Outfit (body)
# Palette: Obsidian bg · Amber gold accent · Steel grays · Signal greens/reds

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Outfit:wght@300;400;500;600;700&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; }

html, body, [class*="css"] {
    font-family: 'Outfit', sans-serif;
    background-color: #07090d;
    color: #c4d4e6;
}

/* ── Streamlit structure ── */
.block-container { padding: 2rem 2.5rem 4rem !important; max-width: 1400px !important; }
.stApp { background: #07090d; }
section[data-testid="stSidebar"] {
    background: #090c11 !important;
    border-right: 1px solid #141e2e !important;
}
section[data-testid="stSidebar"] > div { padding: 1.5rem 1.2rem; }

/* ── Inputs ── */
.stTextInput > div > div > input {
    background: #0d1520 !important;
    color: #c4d4e6 !important;
    border: 1px solid #1c2d45 !important;
    border-radius: 6px !important;
    font-family: 'Outfit', sans-serif !important;
    font-size: 1rem !important;
    padding: 0.75rem 1rem !important;
    transition: border-color 0.2s, box-shadow 0.2s;
}
.stTextInput > div > div > input:focus {
    border-color: #c9940e !important;
    box-shadow: 0 0 0 3px rgba(201,148,14,0.12) !important;
}
.stTextInput > div > div > input::placeholder { color: #2e4460 !important; }

.stSelectbox > div > div {
    background: #0d1520 !important;
    color: #c4d4e6 !important;
    border: 1px solid #1c2d45 !important;
    border-radius: 6px !important;
}
.stNumberInput > div > div > input {
    background: #0d1520 !important;
    color: #c4d4e6 !important;
    border: 1px solid #1c2d45 !important;
    border-radius: 6px !important;
}

/* ── Buttons ── */
.stButton > button {
    background: #c9940e !important;
    color: #07090d !important;
    border: none !important;
    border-radius: 5px !important;
    font-family: 'Space Mono', monospace !important;
    font-weight: 700 !important;
    font-size: 0.78rem !important;
    letter-spacing: 0.08em !important;
    padding: 0.6rem 1.2rem !important;
    transition: all 0.15s !important;
    width: 100% !important;
    text-transform: uppercase !important;
}
.stButton > button:hover {
    background: #e8ab18 !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 6px 24px rgba(201,148,14,0.28) !important;
}
.stButton > button:active { transform: translateY(0) !important; }

/* ── Checkboxes ── */
.stCheckbox > label { color: #5c7a9a !important; font-size: 0.83rem !important; }

/* ── Expanders ── */
.streamlit-expanderHeader {
    background: #0d1520 !important;
    border: 1px solid #141e2e !important;
    border-radius: 6px !important;
    color: #5c7a9a !important;
    font-family: 'Space Mono', monospace !important;
    font-size: 0.72rem !important;
    letter-spacing: 0.06em !important;
}
.streamlit-expanderContent {
    background: #090c11 !important;
    border: 1px solid #141e2e !important;
    border-top: none !important;
    border-radius: 0 0 6px 6px !important;
    padding: 1rem !important;
}

/* ── Alerts ── */
.stInfo    { background: rgba(20,60,110,0.25) !important; border-color: #1c4070 !important; color: #7aa8d8 !important; border-radius: 6px !important; }
.stWarning { background: rgba(160,100,0,0.2) !important;  border-color: #c9940e !important; color: #c9940e !important; border-radius: 6px !important; }
.stError   { background: rgba(160,30,30,0.2) !important;  border-color: #8b1a1a !important; color: #f87171 !important; border-radius: 6px !important; }
.stSuccess { background: rgba(15,90,50,0.2) !important;   border-color: #0f5a32 !important; color: #34d399 !important; border-radius: 6px !important; }

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] { background: transparent !important; border-bottom: 1px solid #141e2e !important; gap: 0; }
.stTabs [data-baseweb="tab"] {
    background: transparent !important;
    color: #2e4460 !important;
    border-bottom: 2px solid transparent !important;
    font-family: 'Space Mono', monospace !important;
    font-size: 0.7rem !important;
    letter-spacing: 0.08em !important;
    padding: 0.5rem 1.2rem !important;
    transition: color 0.15s !important;
}
.stTabs [aria-selected="true"] {
    color: #c9940e !important;
    border-bottom-color: #c9940e !important;
    background: transparent !important;
}

/* ── Divider ── */
hr { border: none !important; border-top: 1px solid #141e2e !important; margin: 1.25rem 0 !important; }
.stCaption { color: #2e4460 !important; font-size: 0.73rem !important; }
label { color: #5c7a9a !important; font-size: 0.83rem !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 3px; }
::-webkit-scrollbar-track { background: #07090d; }
::-webkit-scrollbar-thumb { background: #1c2d45; border-radius: 2px; }

/* ══════════════════════════════════════════════
   CUSTOM COMPONENTS
══════════════════════════════════════════════ */

/* Wordmark */
.ts-wordmark {
    font-family: 'Space Mono', monospace;
    font-size: 1.5rem;
    font-weight: 700;
    color: #c9940e;
    letter-spacing: -0.02em;
}
.ts-tagline {
    font-size: 0.72rem;
    color: #2e4460;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    margin-top: 0.1rem;
}

/* Section label */
.ts-section {
    font-family: 'Space Mono', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: #2e4460;
    border-bottom: 1px solid #141e2e;
    padding-bottom: 0.4rem;
    margin: 1.5rem 0 1rem;
}

/* Sidebar profile */
.ts-profile {
    background: #0d1520;
    border: 1px solid #1c2d45;
    border-left: 3px solid #c9940e;
    border-radius: 6px;
    padding: 0.9rem 1rem;
    margin-bottom: 1rem;
}
.ts-profile-name {
    font-family: 'Space Mono', monospace;
    font-size: 0.9rem;
    color: #c9940e;
    margin-bottom: 0.5rem;
}
.ts-profile-row {
    font-size: 0.78rem;
    color: #3d5c7a;
    line-height: 1.8;
}

/* Pipeline step */
.ts-pipe-hdr {
    font-family: 'Space Mono', monospace;
    font-size: 0.62rem;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: #2e4460;
    margin-bottom: 0.6rem;
}
.ts-step {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-family: 'Space Mono', monospace;
    font-size: 0.72rem;
    padding: 0.2rem 0;
}
.ts-step-done   { color: #1db954; }
.ts-step-active { color: #c9940e; }
.ts-step-wait   { color: #1c2d45; }

/* Search area */
.ts-search-box {
    background: #0d1520;
    border: 1px solid #1c2d45;
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}
.ts-examples {
    font-family: 'Space Mono', monospace;
    font-size: 0.68rem;
    color: #2e4460;
    margin-top: 0.6rem;
    letter-spacing: 0.04em;
}

/* Stats row */
.ts-stat {
    background: #0d1520;
    border: 1px solid #141e2e;
    border-radius: 6px;
    padding: 0.8rem 1rem;
    text-align: center;
}
.ts-stat-val {
    font-family: 'Space Mono', monospace;
    font-size: 1.4rem;
    font-weight: 700;
    color: #c9940e;
    line-height: 1;
}
.ts-stat-lbl {
    font-size: 0.62rem;
    color: #2e4460;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    margin-top: 0.3rem;
}

/* Recommendation banner */
.ts-rec {
    background: linear-gradient(135deg, #0a1a0f 0%, #0a1220 100%);
    border: 1px solid #163024;
    border-left: 4px solid #1db954;
    border-radius: 8px;
    padding: 1.5rem 1.75rem;
    margin-bottom: 1.5rem;
}
.ts-rec-eyebrow {
    font-family: 'Space Mono', monospace;
    font-size: 0.62rem;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: #1db954;
    margin-bottom: 0.5rem;
}
.ts-rec-title {
    font-family: 'Space Mono', monospace;
    font-size: 1.25rem;
    font-weight: 700;
    color: #c4d4e6;
    margin-bottom: 0.2rem;
}
.ts-rec-liner {
    font-size: 0.88rem;
    color: #5c7a9a;
    font-style: italic;
    margin-bottom: 0.9rem;
}
.ts-rec-body {
    font-size: 0.88rem;
    color: #7a9ab8;
    line-height: 1.75;
    border-top: 1px solid #163024;
    padding-top: 0.9rem;
}

/* Confidence pill */
.ts-pill {
    display: inline-block;
    font-family: 'Space Mono', monospace;
    font-size: 0.62rem;
    padding: 2px 10px;
    border-radius: 20px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
.ts-pill-high   { background: rgba(29,185,84,0.12); color: #1db954; border: 1px solid rgba(29,185,84,0.3); }
.ts-pill-medium { background: rgba(201,148,14,0.12); color: #c9940e; border: 1px solid rgba(201,148,14,0.3); }
.ts-pill-low    { background: rgba(92,122,154,0.1); color: #5c7a9a; border: 1px solid rgba(92,122,154,0.2); }

/* Product card */
.ts-card {
    background: #0d1520;
    border: 1px solid #141e2e;
    border-radius: 8px;
    padding: 1.25rem 1.5rem;
    margin-bottom: 0.75rem;
    transition: border-color 0.2s, box-shadow 0.2s;
}
.ts-card:hover {
    border-color: #1c2d45;
    box-shadow: 0 6px 32px rgba(0,0,0,0.5);
}
.ts-card-rank {
    font-family: 'Space Mono', monospace;
    font-size: 0.65rem;
    color: #1c2d45;
    letter-spacing: 0.1em;
    margin-bottom: 0.2rem;
}
.ts-card-name {
    font-size: 1.05rem;
    font-weight: 600;
    color: #c4d4e6;
    line-height: 1.35;
    margin-bottom: 0.75rem;
}
.ts-price {
    font-family: 'Space Mono', monospace;
    font-size: 1.3rem;
    font-weight: 700;
    color: #c9940e;
}
.ts-price-orig {
    font-size: 0.8rem;
    color: #1c2d45;
    text-decoration: line-through;
    margin-left: 0.4rem;
}
.ts-price-disc {
    font-size: 0.75rem;
    color: #1db954;
    margin-left: 0.3rem;
    font-weight: 600;
}
.ts-meta-row {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    flex-wrap: wrap;
    margin-top: 0.5rem;
}
.ts-badge {
    font-family: 'Space Mono', monospace;
    font-size: 0.65rem;
    padding: 2px 8px;
    border-radius: 3px;
    letter-spacing: 0.04em;
}
.ts-badge-gray { background: #0d1520; color: #2e4460; border: 1px solid #141e2e; }
.ts-badge-blue { background: #091729; color: #1565a0; border: 1px solid #0d2a4a; }
.ts-badge-red  { background: #200a0a; color: #b91c1c; border: 1px solid #4a1010; }
.ts-badge-purple{ background: #130920; color: #7c3aed; border: 1px solid #2a1050; }
.ts-badge-green { background: #091a10; color: #15803d; border: 1px solid #0d3020; }
.ts-badge-amber { background: #1a1000; color: #b45309; border: 1px solid #3a2200; }

.ts-link {
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    color: #1c4070 !important;
    text-decoration: none;
    letter-spacing: 0.04em;
    transition: color 0.15s;
}
.ts-link:hover { color: #5c7a9a !important; }

/* Trust score ring */
.ts-ring {
    width: 70px; height: 70px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Space Mono', monospace;
    font-weight: 700;
    font-size: 1rem;
    border: 3px solid;
    flex-shrink: 0;
}
.ts-ring-high   { border-color: #1db954; color: #1db954; background: rgba(29,185,84,0.07); }
.ts-ring-medium { border-color: #c9940e; color: #c9940e; background: rgba(201,148,14,0.07); }
.ts-ring-low    { border-color: #dc2626; color: #dc2626; background: rgba(220,38,38,0.07); }
.ts-ring-na     { border-color: #1c2d45; color: #1c2d45; background: transparent; }

/* Dimension bars */
.ts-dim { margin-bottom: 0.55rem; }
.ts-dim-hdr {
    display: flex;
    justify-content: space-between;
    font-family: 'Space Mono', monospace;
    font-size: 0.65rem;
    color: #3d5c7a;
    margin-bottom: 0.2rem;
}
.ts-bar-bg { height: 3px; background: #141e2e; border-radius: 2px; overflow: hidden; }
.ts-bar-fill { height: 100%; border-radius: 2px; }

/* Review card */
.ts-review {
    background: #07090d;
    border: 1px solid #141e2e;
    border-radius: 6px;
    padding: 0.8rem 1rem;
    margin-bottom: 0.45rem;
    font-size: 0.84rem;
    line-height: 1.65;
}
.ts-review-meta { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.35rem; }
.ts-review-body { color: #5c7a9a; }
.ts-review-foot { margin-top: 0.35rem; font-size: 0.68rem; color: #1c2d45; font-family: 'Space Mono', monospace; }

/* Flag chips */
.ts-flag-warn {
    display: inline-block;
    background: rgba(220,38,38,0.1);
    border: 1px solid rgba(220,38,38,0.2);
    color: #f87171;
    border-radius: 3px;
    padding: 2px 8px;
    font-size: 0.68rem;
    margin: 2px;
    font-family: 'Space Mono', monospace;
}
.ts-flag-ok {
    display: inline-block;
    background: rgba(29,185,84,0.1);
    border: 1px solid rgba(29,185,84,0.2);
    color: #1db954;
    border-radius: 3px;
    padding: 2px 8px;
    font-size: 0.68rem;
    margin: 2px;
    font-family: 'Space Mono', monospace;
}

/* Per-review credibility score */
.ts-rev-score {
    border-radius: 5px;
    padding: 5px 8px;
    font-family: 'Space Mono', monospace;
    font-weight: 700;
    font-size: 0.8rem;
    text-align: center;
    color: #07090d;
}

/* Summary card */
.ts-summary-card {
    background: #0a1218;
    border: 1px solid #141e2e;
    border-radius: 6px;
    padding: 0.9rem 1rem;
    margin-bottom: 0.5rem;
}
.ts-summary-name { font-weight: 600; color: #c4d4e6; font-size: 0.9rem; }
.ts-summary-note { font-size: 0.78rem; color: #3d5c7a; margin-top: 0.2rem; }

/* Sources footer */
.ts-sources-footer {
    background: #090c11;
    border: 1px solid #141e2e;
    border-radius: 6px;
    padding: 0.75rem 1rem;
    font-family: 'Space Mono', monospace;
    font-size: 0.7rem;
    color: #2e4460;
    margin-top: 1rem;
}

/* Welcome */
.ts-welcome { color: #2e4460; font-size: 0.82rem; margin-top: 0.4rem; }
</style>
""", unsafe_allow_html=True)


# ── Helpers ────────────────────────────────────────────────────────────────────

def save_profile(p):   st.session_state["user_profile"] = p
def load_profile():    return st.session_state.get("user_profile", None)
def clear_profile():   st.session_state.pop("user_profile", None)

def ring_cls(score):
    if score is None:  return "ts-ring-na"
    if score >= 70:    return "ts-ring-high"
    if score >= 45:    return "ts-ring-medium"
    return "ts-ring-low"

def bar_color(score):
    if score >= 70: return "#1db954"
    if score >= 45: return "#c9940e"
    return "#dc2626"

def pill_cls(c):
    return {"high":"ts-pill-high","medium":"ts-pill-medium"}.get(c,"ts-pill-low")

def source_badge(tier):
    cfg = {
        "ecommerce": ("ts-badge-blue",   "▪ ECOM"),
        "community": ("ts-badge-purple",  "◈ COMMUNITY"),
        "video":     ("ts-badge-red",     "▶ VIDEO"),
        "dedicated": ("ts-badge-green",   "◆ EXPERT"),
        "blog":      ("ts-badge-amber",   "◇ BLOG"),
    }
    cls, label = cfg.get(tier, ("ts-badge-gray", tier.upper()))
    return f"<span class='ts-badge {cls}'>{label}</span>"

def api_search(query: str, profile: Optional[dict] = None) -> dict:
    try:
        resp = requests.post(
            f"{API_BASE}/api/search",
            json={"query": query, "user_profile": profile},
            timeout=600,  # 3 minutes for full pipeline
        )
        return resp.json()
    except requests.exceptions.Timeout:
        return {"success": False, "error": "Search took too long (>3 min). Your Gemini API may be rate-limited. Please check your API key billing."}
    except requests.exceptions.ConnectionError:
        return {"success": False, "error": "Cannot connect to backend on port 8000. Is the backend running?"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def compute_review_score(r: dict) -> float:
    score = 50.0
    body  = (r.get("body") or "").strip()
    meta  = r.get("reviewer_metadata") or {}
    if meta.get("verified_purchase"): score += 15
    hv = int(r.get("helpful_votes") or 0)
    score += min(20, hv * 2)
    age = meta.get("account_age_days")
    if age is not None:
        score += 10 if age > 365 else (-10 if age < 30 else 0)
    words = len(body.split())
    score += (-15 if words < 10 else 5 if words > 40 else 0)
    return max(0.0, min(100.0, round(score, 1)))


# ── Sidebar ────────────────────────────────────────────────────────────────────

def render_sidebar():
    with st.sidebar:
        st.markdown("<div class='ts-wordmark'>◈ TRUSTSHOP</div>", unsafe_allow_html=True)
        st.markdown("<div class='ts-tagline'>Review Intelligence</div>", unsafe_allow_html=True)
        st.markdown("<hr>", unsafe_allow_html=True)

        profile = load_profile()
        if profile:
            cats = ", ".join(profile.get("preferred_categories", [])[:2])
            st.markdown(f"""
            <div class="ts-profile">
                <div class="ts-profile-name">{profile['name']}</div>
                <div class="ts-profile-row">
                    📍 {profile['location']}<br>
                    🎂 {profile['age']} · {profile['gender'].title()}<br>
                    💰 {profile['budget_style'].replace('_',' ').title()}<br>
                    🏷 {cats}
                </div>
            </div>
            """, unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            with c1:
                if st.button("EDIT"):  st.session_state["show_profile_form"] = True; st.rerun()
            with c2:
                if st.button("CLEAR"): clear_profile(); st.rerun()
        else:
            st.markdown("<div style='color:#2e4460;font-size:0.8rem;margin-bottom:0.75rem'>No profile. Add one for personalised results.</div>", unsafe_allow_html=True)
            if st.button("SET UP PROFILE"):
                st.session_state["show_profile_form"] = True; st.rerun()

        st.markdown("<hr>", unsafe_allow_html=True)

        completed = st.session_state.get("completed_agents", [])
        stage     = st.session_state.get("pipeline_stage", "idle")
        steps = [
            ("query_understanding",  "QUERY PARSE"),
            ("product_discovery",    "PRODUCTS"),
            ("review_aggregation",   "REVIEWS"),
            ("authenticity_scoring", "AUTH SCORE"),
            ("explainability",       "SYNTHESISE"),
        ]

        st.markdown("<div class='ts-pipe-hdr'>Pipeline</div>", unsafe_allow_html=True)
        for key, label in steps:
            if key in completed:
                st.markdown(f"<div class='ts-step ts-step-done'>✓ {label}</div>", unsafe_allow_html=True)
            elif stage == "searching":
                st.markdown(f"<div class='ts-step ts-step-wait'>○ {label}</div>", unsafe_allow_html=True)
            else:
                st.markdown(f"<div class='ts-step ts-step-wait'>○ {label}</div>", unsafe_allow_html=True)

        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("<div style='font-family:Space Mono,monospace;font-size:0.62rem;color:#141e2e'>v1.0 · Research Prototype</div>", unsafe_allow_html=True)


# ── Profile Form ───────────────────────────────────────────────────────────────

def render_profile_form():
    st.markdown("<div class='ts-section'>User Profile</div>", unsafe_allow_html=True)
    st.markdown("<div style='color:#3d5c7a;font-size:0.88rem;margin-bottom:1.5rem'>Tell us about yourself for personalised, relevant recommendations.</div>", unsafe_allow_html=True)

    profile = load_profile() or {}
    with st.form("profile_form"):
        c1, c2 = st.columns(2)
        with c1:
            name   = st.text_input("Full Name",   value=profile.get("name",""),     placeholder="Arjun Mehta")
            age    = st.number_input("Age", 13, 100, value=profile.get("age", 25))
            gender = st.selectbox("Gender", ["male","female","other"],
                       index=["male","female","other"].index(profile.get("gender","male")))
        with c2:
            location     = st.text_input("City, State", value=profile.get("location",""), placeholder="Mumbai, Maharashtra")
            budget_style = st.selectbox("Spending Style",
                             ["value","mid_range","premium"],
                             index=["value","mid_range","premium"].index(profile.get("budget_style","mid_range")),
                             format_func=lambda x: {
                                 "value":     "₹  Value — best bang for buck",
                                 "mid_range": "₹₹ Mid-range — quality + price",
                                 "premium":   "₹₹₹ Premium — quality first",
                             }[x])

        st.markdown("<div style='color:#5c7a9a;font-size:0.8rem;margin:1rem 0 0.5rem'>Categories you shop for</div>", unsafe_allow_html=True)
        cats     = ["electronics","audio","phones","computers","fashion","fitness","personal_care","gaming","home_appliances","sports"]
        existing = profile.get("preferred_categories", [])
        cols     = st.columns(4)
        selected = [c for i,c in enumerate(cats) if cols[i%4].checkbox(c.replace("_"," ").title(), value=c in existing, key=f"c_{c}")]

        c3, c4 = st.columns(2)
        with c3: pref  = st.text_input("Preferred Brands", value=", ".join(profile.get("preferred_brands",[])), placeholder="Sony, Apple, Nike")
        with c4: avoid = st.text_input("Brands to Avoid",  value=", ".join(profile.get("avoided_brands",[])),  placeholder="boAt, Noise")

        if st.form_submit_button("SAVE PROFILE", use_container_width=True):
            if not name or not location:
                st.error("Name and location are required."); return
            if not selected:
                st.error("Select at least one category."); return
            save_profile({
                "user_id":              profile.get("user_id", str(uuid.uuid4())),
                "name":                 name.strip(), "age": int(age), "gender": gender,
                "location":             location.strip(), "budget_style": budget_style,
                "preferred_categories": selected,
                "preferred_brands":     [b.strip() for b in pref.split(",")  if b.strip()],
                "avoided_brands":       [b.strip() for b in avoid.split(",") if b.strip()],
            })
            st.session_state["show_profile_form"] = False
            st.success("Profile saved."); st.rerun()


# ── Dimension Bars ─────────────────────────────────────────────────────────────

def render_dimension_bars(dimensions: dict):
    labels = {
        "cross_source_consensus":  "CROSS-SOURCE",
        "platform_authenticity":   "PLATFORM",
        "source_credibility":      "CREDIBILITY",
        "linguistic_authenticity": "LINGUISTIC",
        "temporal_authenticity":   "TEMPORAL",
    }
    for key, label in labels.items():
        dim = dimensions.get(key, {})
        if not dim: continue
        score = dim.get("score", 0) or 0
        conf  = dim.get("confidence", "low")
        color = bar_color(score)
        st.markdown(f"""
        <div class="ts-dim">
            <div class="ts-dim-hdr">
                <span>{label}</span>
                <span style="color:{color}">{score:.0f}<span style="color:#1c2d45;font-size:0.58rem"> · {conf}</span></span>
            </div>
            <div class="ts-bar-bg"><div class="ts-bar-fill" style="width:{score}%;background:{color}"></div></div>
        </div>
        """, unsafe_allow_html=True)


# ── Product Card ───────────────────────────────────────────────────────────────

def render_product_card(product: dict, rank: int, state: dict):
    pid        = product.get("id", "")
    name       = product.get("name", "Unknown")
    price      = product.get("price", 0)
    orig_price = product.get("original_price")
    platform   = product.get("platform", "—")
    rating     = product.get("rating")
    url        = product.get("url", "")
    image_url  = product.get("image_url", "")

    auth_scores = (state or {}).get("authenticity_scores") or {}
    p_score     = auth_scores.get(pid) or {}
    overall     = p_score.get("overall_score") if p_score else None
    dimensions  = p_score.get("dimensions", {}) if p_score else {}
    flags       = p_score.get("flags", []) if p_score else []
    tot_rev     = p_score.get("total_reviews", 0) if p_score else 0
    src_count   = p_score.get("sources_count", 0) if p_score else 0

    aggregated      = (state or {}).get("aggregated_reviews") or {}
    product_reviews = aggregated.get(pid, [])

    # Price HTML
    disc_html = ""
    if orig_price and orig_price > price:
        pct = round((1 - price / orig_price) * 100)
        disc_html = f"<span class='ts-price-orig'>₹{orig_price:,.0f}</span><span class='ts-price-disc'>-{pct}%</span>"

    # Rating HTML
    rating_html = ""
    if rating:
        filled = "★" * round(rating)
        empty  = "☆" * (5 - round(rating))
        rating_html = f"<span style='color:#c9940e'>{filled}</span><span style='color:#141e2e'>{empty}</span> <span style='color:#2e4460;font-size:0.8rem'>{rating}</span>"

    st.markdown(f"""
    <div class="ts-card">
        <div class="ts-card-rank">#{rank:02d} &nbsp;·&nbsp; {platform.upper()}</div>
        <div class="ts-card-name">{name}</div>
    </div>
    """, unsafe_allow_html=True)

    img_col, info_col, ring_col = st.columns([1, 5, 1])

    with img_col:
        if image_url:
            st.image(image_url, width=90)
        else:
            st.markdown("<div style='width:80px;height:80px;background:#0d1520;border:1px solid #141e2e;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#1c2d45;font-size:1.4rem'>◈</div>", unsafe_allow_html=True)

    with info_col:
        st.markdown(f"""
        <div style="margin-bottom:0.5rem">
            <span class="ts-price">₹{price:,.0f}</span> {disc_html}
        </div>
        <div class="ts-meta-row">
            <span class="ts-badge ts-badge-gray">🏪 {platform}</span>
            {rating_html}
            {"<span style='color:#2e4460;font-size:0.72rem;font-family:Space Mono,monospace'>" + str(tot_rev) + " reviews · " + str(src_count) + " sources</span>" if tot_rev else ""}
        </div>
        {f"<a href='{url}' target='_blank' class='ts-link' style='display:inline-block;margin-top:0.5rem'>VIEW PRODUCT ↗</a>" if url else ""}
        """, unsafe_allow_html=True)

    with ring_col:
        rc = ring_cls(overall)
        val = f"{overall:.0f}" if overall is not None else "—"
        st.markdown(f"""
        <div style="display:flex;flex-direction:column;align-items:center;gap:4px">
            <div class="ts-ring {rc}">{val}</div>
            <div style="font-family:Space Mono,monospace;font-size:0.55rem;color:#1c2d45;text-align:center;letter-spacing:0.06em">TRUST</div>
        </div>
        """, unsafe_allow_html=True)

    # ── Expandable details ─────────────────────────────────────────────────────
    with st.expander(f"◈  ANALYSIS — {name[:45]}"):
        tab_auth, tab_reviews = st.tabs(["◆ AUTHENTICITY", "◈ REVIEWS"])

        with tab_auth:
            if not p_score:
                st.markdown("<div style='color:#2e4460;font-size:0.82rem'>No authenticity data available.</div>", unsafe_allow_html=True)
            else:
                render_dimension_bars(dimensions)

                # Flags removed from UI by request — kept for internal state only

        with tab_reviews:
            if not product_reviews:
                st.markdown("<div style='color:#2e4460;font-size:0.82rem'>No reviews collected for this product.</div>", unsafe_allow_html=True)
            else:
                by_source = {}
                for r in product_reviews:
                    src = r.get("source_platform","unknown")
                    by_source.setdefault(src, []).append(r)

                source_tabs = st.tabs([f"{s.upper()} ({len(rs)})" for s, rs in by_source.items()])
                for stab, (src, rs) in zip(source_tabs, by_source.items()):
                    with stab:
                        for r in rs[:5]:
                            tier      = r.get("source_tier","ecommerce")
                            body      = (r.get("body") or "").strip()
                            rat       = r.get("rating")
                            meta      = r.get("reviewer_metadata") or {}
                            hv        = r.get("helpful_votes") or 0
                            date      = (r.get("review_date") or "")[:10]
                            rev_score = compute_review_score(r)
                            score_col_color = bar_color(rev_score)
                            inferred  = meta.get("rating_inferred", False)

                            rat_html = ""
                            if rat is not None:
                                s = "★" * round(rat) + "☆" * (5-round(rat))
                                note = "<span style='color:#1c2d45;font-size:0.6rem'> inferred</span>" if inferred else ""
                                rat_html = f"<span style='color:#c9940e;font-size:0.85rem'>{s}</span>{note}"

                            foot = " · ".join(filter(None, [
                                "✓ verified"     if meta.get("verified_purchase") else "",
                                f"acct {meta['account_age_days']}d" if meta.get("account_age_days") else "",
                                f"↑ {hv}"        if hv else "",
                                date,
                            ]))

                            rc1, rc2 = st.columns([6,1])
                            with rc1:
                                st.markdown(f"""
                                <div class="ts-review">
                                    <div class="ts-review-meta">{source_badge(tier)} {rat_html}</div>
                                    <div class="ts-review-body">{body[:400]}</div>
                                    <div class="ts-review-foot">{foot}</div>
                                </div>
                                """, unsafe_allow_html=True)
                            with rc2:
                                st.markdown(f"<div class='ts-rev-score' style='background:{score_col_color}'>{rev_score:.0f}</div>", unsafe_allow_html=True)


# ── Recommendation Banner ──────────────────────────────────────────────────────

def render_recommendation(final: dict):
    if not final or not isinstance(final, dict):
        return

    top = final.get("top_pick") or {}
    if not top:
        return

    conf     = top.get("confidence", "low")
    conf_cls = pill_cls(conf)

    st.markdown(f"""
    <div class="ts-rec">
        <div class="ts-rec-eyebrow">◆ Top Recommendation</div>
        <div style="display:flex;align-items:baseline;gap:0.75rem;flex-wrap:wrap;margin-bottom:0.2rem">
            <div class="ts-rec-title">{top.get('product_name','—')}</div>
            <span class="ts-pill {conf_cls}">{conf} confidence</span>
        </div>
        <div class="ts-rec-liner">"{top.get('one_liner','')}"</div>
        <div class="ts-rec-body">{top.get('reasoning','')}</div>
    </div>
    """, unsafe_allow_html=True)

    # Summaries
    summaries = final.get("product_summaries") or []
    if summaries:
        st.markdown("<div class='ts-section'>Product Summaries</div>", unsafe_allow_html=True)
        for ps in summaries:
            verdict = ps.get("trust_verdict","")
            v_color = {"Trustworthy":"#1db954","Mixed Signals":"#c9940e","Suspicious":"#dc2626"}.get(verdict,"#5c7a9a")
            pos = ps.get("key_positives") or []
            con = ps.get("key_concerns") or []
            st.markdown(f"""
            <div class="ts-summary-card">
                <div style="display:flex;align-items:center;justify-content:space-between">
                    <span class="ts-summary-name">{ps.get('product_name','—')}</span>
                    <span style="color:{v_color};font-family:Space Mono,monospace;font-size:0.65rem;letter-spacing:0.08em">{verdict.upper()}</span>
                </div>
                <div class="ts-summary-note">{ps.get('authenticity_note','')}</div>
                {"<div style='margin-top:0.4rem'>" + "".join(f"<span class='ts-flag-ok'>✓ {p[:65]}</span>" for p in pos[:2]) + "</div>" if pos else ""}
                {"<div style='margin-top:0.3rem'>" + "".join(f"<span class='ts-flag-warn'>⚠ {c[:65]}</span>" for c in con[:2]) + "</div>" if con else ""}
            </div>
            """, unsafe_allow_html=True)

    src_summary  = final.get("sources_summary","")
    overall_conf = final.get("overall_confidence","")
    disclaimer   = final.get("disclaimer","")

    if src_summary:
        conf_bit = f" · Confidence: <span style='color:#c9940e'>{overall_conf.upper()}</span>" if overall_conf else ""
        st.markdown(f"<div class='ts-sources-footer'>{src_summary}{conf_bit}</div>", unsafe_allow_html=True)

    if disclaimer:
        st.warning(f"⚠ {disclaimer}")


# ── Main Search ────────────────────────────────────────────────────────────────

def render_search():
    profile = load_profile()

    # Header
    st.markdown(f"""
    <div style="margin-bottom:2rem">
        <div class="ts-wordmark" style="font-size:2.2rem">◈ TRUSTSHOP</div>
        <div class="ts-tagline">Cross-platform review intelligence · Authenticity scoring</div>
        {"<div class='ts-welcome'>Signed in as " + profile['name'] + "</div>" if profile else ""}
    </div>
    """, unsafe_allow_html=True)

    # Search box
    st.markdown("<div class='ts-search-box'>", unsafe_allow_html=True)
    query = st.text_input(
        "Search",
        placeholder="best wireless headphones under ₹5000 for gym, not boAt",
        label_visibility="collapsed",
        key="search_input",
    )
    st.markdown("""
    <div class="ts-examples">
    TRY → gaming laptop under 70000 &nbsp;·&nbsp; wireless earbuds under 3000 &nbsp;·&nbsp; moisturizer for oily skin
    </div>
    """, unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    _, btn_col = st.columns([5,1])
    with btn_col:
        clicked = st.button("SEARCH ◈", use_container_width=True)

    if clicked and not query:
        st.warning("Enter a search query to continue.")

    if clicked and query:
        st.session_state["pipeline_stage"] = "searching"
        with st.spinner("Running intelligence pipeline..."):
            result = api_search(query, profile=profile)

        if not result.get("success"):
            st.error(f"Pipeline error: {result.get('error')}"); return

        stage = result.get("stage")
        st.session_state["pipeline_stage"] = stage
        st.session_state["last_result"]    = result
        st.session_state["completed_agents"] = result.get("completed_agents", [])
        st.rerun()

    result = st.session_state.get("last_result")
    if not result: return

    st.markdown("<hr>", unsafe_allow_html=True)

    stage = result.get("stage","")
    state = result.get("state") or {}
    if not state:
        # Flatten — some pipeline versions return fields at top level
        state = result

    intent   = state.get("parsed_intent") or result.get("parsed_intent") or {}
    products = (state.get("candidate_products") or
                state.get("top_products_ranked") or
                result.get("products") or [])

    # Intent summary
    with st.expander("◈ PARSED INTENT", expanded=False):
        ic1, ic2, ic3 = st.columns(3)
        with ic1:
            st.markdown(f"**Product** `{intent.get('product_type') or '—'}`")
            st.markdown(f"**Category** `{intent.get('category') or '—'}`")
            st.markdown(f"**Use Case** `{intent.get('use_case') or '—'}`")
        with ic2:
            bmax = intent.get("budget_max")
            bmin = intent.get("budget_min")
            budget_str = f"₹{bmin or 0:,.0f} – ₹{bmax:,.0f}" if bmax else "—"
            st.markdown(f"**Budget** `{budget_str}`")
            st.markdown(f"**Requirements** `{', '.join(intent.get('requirements',[]) or []) or '—'}`")
        with ic3:
            st.markdown(f"**Deal Breakers** `{', '.join(intent.get('deal_breakers',[]) or []) or '—'}`")
            if intent.get("inferred"):
                st.info(f"Inferred from profile: {', '.join(intent['inferred'])}")

    if stage == "clarification_needed":
        cq = state.get("clarification_question") or result.get("clarification_question","")
        st.warning(f"🤔 {cq}"); return

    if not products:
        st.warning("No products found. Try a different query."); return

    # Stats
    auth_scores  = state.get("authenticity_scores") or result.get("authenticity_scores") or {}
    reviews_map  = state.get("aggregated_reviews")  or result.get("aggregated_reviews")  or {}
    total_rev    = sum(len(v) for v in reviews_map.values())
    all_sources  = set(
        r.get("source_platform","")
        for reviews in reviews_map.values()
        for r in reviews
    )
    avg_score    = (sum((auth_scores.get(p.get("id")) or {}).get("overall_score",0) for p in products)
                    / max(len(products),1))

    s1, s2, s3, s4 = st.columns(4)
    for col, val, lbl in [
        (s1, len(products),       "Products"),
        (s2, total_rev,           "Reviews"),
        (s3, len(all_sources),    "Sources"),
        (s4, f"{avg_score:.0f}",  "Avg Trust"),
    ]:
        with col:
            st.markdown(f"<div class='ts-stat'><div class='ts-stat-val'>{val}</div><div class='ts-stat-lbl'>{lbl}</div></div>", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Recommendation
    final = state.get("final_recommendation") or result.get("final_recommendation")
    if final and isinstance(final, dict) and final.get("top_pick"):
        render_recommendation(final)

    # Products
    st.markdown("<div class='ts-section'>Products Ranked by Authenticity</div>", unsafe_allow_html=True)
    for i, product in enumerate(products, 1):
        render_product_card(product, i, state if state else result)

    # Explainability fallback if final was a string
    if final and not isinstance(final, dict):
        st.markdown("<div class='ts-section'>Recommendation</div>", unsafe_allow_html=True)
        st.info(str(final))


# ── Entry ──────────────────────────────────────────────────────────────────────

def main():
    render_sidebar()
    if st.session_state.get("show_profile_form") or not load_profile():
        render_profile_form()
    else:
        render_search()

if __name__ == "__main__":
    main()