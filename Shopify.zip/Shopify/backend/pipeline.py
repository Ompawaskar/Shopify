"""
LangGraph Pipeline — Shopping Assistant

Defines the agent graph and shared state flow:

  START
    ↓
  query_understanding   → parses intent from raw query
    ↓
  [clarification check] → if vague, stop and return question
    ↓
  product_discovery     → fetches real-time products
    ↓
  review_aggregation    → fetches reviews from all sources in parallel
    ↓
  authenticity_scoring  → scores review authenticity (stub — next sprint)
    ↓
  explainability        → generates final recommendation (stub — next sprint)
    ↓
  END

Each node reads from ShoppingState and writes its output back.
The graph is compiled once at startup and reused for all requests.
"""

from typing import Any
from langgraph.graph import StateGraph, END
from models import ShoppingState, ParsedIntent
from agents.query_understanding import QueryUnderstandingAgent
from agents.product_discovery import ProductDiscoveryAgent
from agents.review_aggregation import ReviewAggregationAgent
from agents.authenticity_scoring import AuthenticityScorer
from agents.explanibility import ExplainabilityAgent


# ── Agent instances (shared, stateless) ───────────────────────────────────────

query_agent = QueryUnderstandingAgent()
discovery_agent = ProductDiscoveryAgent()
review_agent = ReviewAggregationAgent()
auth_scorer = AuthenticityScorer()
explain_agent = ExplainabilityAgent()


# ── Node Functions ─────────────────────────────────────────────────────────────
# Each node receives the full state dict, modifies it, returns updated dict.
# LangGraph merges returned dict back into state automatically.

async def node_query_understanding(state: dict) -> dict:
    """
    Agent 1: Parse natural language query into structured intent.
    Reads  : user_query, user_profile
    Writes : parsed_intent, needs_clarification, clarification_question
    """
    print(f"\n[Pipeline] ▶ query_understanding — '{state['user_query']}'")

    profile_dict = state.get("user_profile")
    profile = None
    if profile_dict:
        from models import UserProfile
        profile = UserProfile(**profile_dict)

    intent: ParsedIntent = await query_agent.parse(
        query=state["user_query"],
        profile=profile
    )

    updates = {
        "current_agent": "query_understanding",
        "completed_agents": state.get("completed_agents", []) + ["query_understanding"],
        "parsed_intent": intent.model_dump(),
        "needs_clarification": intent.needs_clarification,
        "clarification_question": intent.clarification_question,
    }

    print(f"[Pipeline] ✅ query_understanding — product: {intent.product_type}, "
          f"budget: {intent.budget_max}, clarification: {intent.needs_clarification}")

    return updates


async def node_product_discovery(state: dict) -> dict:
    """
    Agent 2: Fetch real-time products matching the parsed intent.
    Reads  : parsed_intent, user_profile
    Writes : candidate_products
    """
    print(f"[Pipeline] ▶ product_discovery")

    intent = ParsedIntent(**state["parsed_intent"])
    
    profile_dict = state.get("user_profile")
    profile = None
    if profile_dict:
        from models import UserProfile
        profile = UserProfile(**profile_dict)

    products = await discovery_agent.discover(intent, profile=profile)
    
    print(f"[Pipeline DEBUG] Discovered {len(products)} products: {[p.name for p in products]}")

    updates = {
        "current_agent": "product_discovery",
        "completed_agents": state.get("completed_agents", []) + ["product_discovery"],
        "candidate_products": [p.model_dump() for p in products],
    }

    print(f"[Pipeline] ✅ product_discovery — {len(products)} products found")
    print(f"[Pipeline DEBUG] candidate_products in updates: {len(updates['candidate_products'])}")
    return updates


async def node_review_aggregation(state: dict) -> dict:
    """
    Agent 3: Fetch and normalize reviews from all sources for each product.
    Reads  : candidate_products
    Writes : aggregated_reviews, review_sources_used
    """
    print(f"[Pipeline] ▶ review_aggregation — "
          f"{len(state['candidate_products'])} products")

    products = state["candidate_products"]
    print(f"[Pipeline DEBUG] Review aggregation input products: {len(products)}")
    print(f"[Pipeline DEBUG] Product names: {[p.get('name') for p in products]}")
    
    aggregated = await review_agent.aggregate(products)

    # Track which sources contributed reviews per product
    sources_used = {}
    for product_id, reviews in aggregated.items():
        sources = list(set(r["source_platform"] for r in reviews))
        sources_used[product_id] = sources

    total_reviews = sum(len(r) for r in aggregated.values())

    updates = {
        "current_agent": "review_aggregation",
        "completed_agents": state.get("completed_agents", []) + ["review_aggregation"],
        "aggregated_reviews": aggregated,
        "review_sources_used": sources_used,
        # Preserve all previous fields
        "candidate_products": state.get("candidate_products", []),
        "parsed_intent": state.get("parsed_intent"),
        "needs_clarification": state.get("needs_clarification", False),
    }

    print(f"[Pipeline DEBUG] Review aggregation output: {total_reviews} reviews, sources_used keys: {list(sources_used.keys())}")
    print(f"[Pipeline DEBUG] Preserving candidate_products: {len(updates.get('candidate_products', []))}")
    print(f"[Pipeline] ✅ review_aggregation — {total_reviews} total reviews")
    return updates


async def node_authenticity_scoring(state: dict) -> dict:
    """
    Agent 4: Score review authenticity per product. (Full implementation — next sprint)
    Reads  : aggregated_reviews
    Writes : authenticity_scores
    """
    print(f"[Pipeline] ▶ authenticity_scoring")
    print(f"[Pipeline DEBUG] Authenticity input: candidate_products={len(state.get('candidate_products', []))}, aggregated_reviews={len(state.get('aggregated_reviews', {}))}")

    aggregated = state.get("aggregated_reviews", {}) or {}

    try:
        # Use the new AuthenticityScorer to compute full scores
        scores = await auth_scorer.score_all(aggregated)
    except Exception as e:
        print(f"[Pipeline] Authenticity scoring failed: {e}")
        # Fallback: keep previously computed (if any) or empty
        scores = state.get("authenticity_scores", {}) or {}

    updates = {
        "current_agent": "authenticity_scoring",
        "completed_agents": state.get("completed_agents", []) + ["authenticity_scoring"],
        "authenticity_scores": scores,
        # Preserve all previous fields
        "candidate_products": state.get("candidate_products", []),
        "aggregated_reviews": state.get("aggregated_reviews", {}),
        "review_sources_used": state.get("review_sources_used", {}),
        "parsed_intent": state.get("parsed_intent"),
        "needs_clarification": state.get("needs_clarification", False),
    }

    print(f"[Pipeline DEBUG] Authenticity output: scored {len(scores)} products")
    print(f"[Pipeline] ✅ authenticity_scoring — completed")
    return updates


async def node_explainability(state: dict) -> dict:
    """
    Agent 5: Generate final recommendation with reasoning. (Stub — next sprint)
    Reads  : candidate_products, authenticity_scores
    Writes : final_recommendation, top_products_ranked
    """
    print(f"[Pipeline] ▶ explainability")
    print(f"[Pipeline DEBUG] Explainability input: candidate_products={len(state.get('candidate_products', []))}, aggregated_reviews={len(state.get('aggregated_reviews', {}))}")

    parsed_intent = state.get("parsed_intent") or {}
    products = state.get("candidate_products", []) or []
    authenticity_scores = state.get("authenticity_scores", {}) or {}
    aggregated_reviews = state.get("aggregated_reviews", {}) or {}
    review_sources_used = state.get("review_sources_used", {}) or {}

    try:
        explain_result = await explain_agent.explain(
            parsed_intent=parsed_intent,
            products=products,
            authenticity_scores=authenticity_scores,
            aggregated_reviews=aggregated_reviews,
            review_sources_used=review_sources_used,
        )
    except Exception as e:
        print(f"[Pipeline] Explainability agent failed: {e}")
        explain_result = {
            "top_pick": None,
            "product_summaries": [],
            "top_products_ranked": [],
            "sources_summary": "Explainability failed",
        }

    # Ensure top_products_ranked is available for downstream
    top_ranked = explain_result.get("top_products_ranked") or []

    updates = {
        "current_agent": "explainability",
        "completed_agents": state.get("completed_agents", []) + ["explainability"],
        "final_recommendation": explain_result,
        "top_products_ranked": top_ranked,
        # Preserve all previous fields
        "candidate_products": state.get("candidate_products", []),
        "aggregated_reviews": aggregated_reviews,
        "review_sources_used": review_sources_used,
        "authenticity_scores": authenticity_scores,
        "parsed_intent": parsed_intent,
        "needs_clarification": state.get("needs_clarification", False),
    }

    print(f"[Pipeline DEBUG] Explainability output: produced top {len(top_ranked)} ranked products")
    print(f"[Pipeline] ✅ explainability — completed")
    return updates


# ── Conditional Edge: After Query Understanding ────────────────────────────────

def route_after_query(state: dict) -> str:
    """
    If the query needs clarification, stop the pipeline and return to user.
    Otherwise continue to product discovery.
    """
    if state.get("needs_clarification"):
        return "end"
    return "product_discovery"


# ── Build the Graph ────────────────────────────────────────────────────────────

def build_pipeline():
    # State schema — LangGraph uses dict, we validate with ShoppingState separately
    workflow = StateGraph(dict)

    # Register all nodes
    workflow.add_node("query_understanding", node_query_understanding)
    workflow.add_node("product_discovery", node_product_discovery)
    workflow.add_node("review_aggregation", node_review_aggregation)
    workflow.add_node("authenticity_scoring", node_authenticity_scoring)
    workflow.add_node("explainability", node_explainability)

    # Entry point
    workflow.set_entry_point("query_understanding")

    # Conditional edge after query understanding
    workflow.add_conditional_edges(
        "query_understanding",
        route_after_query,
        {
            "end": END,
            "product_discovery": "product_discovery",
        },
    )

    # Linear edges for the rest of the pipeline
    workflow.add_edge("product_discovery", "review_aggregation")
    workflow.add_edge("review_aggregation", "authenticity_scoring")
    workflow.add_edge("authenticity_scoring", "explainability")
    workflow.add_edge("explainability", END)

    return workflow.compile()


# Single compiled pipeline instance — reused for all requests
pipeline = build_pipeline()