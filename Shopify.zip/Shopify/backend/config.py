from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    GEMINI_API_KEY: str
    GEMINI_KEY2: Optional[str] = None
    SERPAPI_KEY: str
    REDDIT_CLIENT_ID: Optional[str] = None
    REDDIT_CLIENT_SECRET: Optional[str] = None
    REDDIT_USER_AGENT: str = "ShoppingAssistant/1.0"
    YOUTUBE_API_KEY: Optional[str] = None

    class Config:
        env_file = ".env"

settings = Settings()