from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from models import (
    ParseQueryRequest, ParseQueryResponse,
    SearchRequest, SearchResponse,
    SaveProfileRequest, SaveProfileResponse,
    UserProfile, ShoppingState
)
from pipeline import pipeline

app = FastAPI(title="Shopping Assistant API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Health ─────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "pipeline": "langgraph", "agents": ["query_understanding", "product_discovery", "review_aggregation", "authenticity_scoring", "explainability"]}


# ── Profile ────────────────────────────────────────────────────────────────────

@app.post("/api/profile/validate", response_model=SaveProfileResponse)
async def validate_profile(request: SaveProfileRequest):
    return SaveProfileResponse(
        success=True,
        message=f"Profile valid for {request.profile.name}"
    )


# ── Full Pipeline: Query → Products → Reviews → Scoring → Explainability ──────

@app.post("/api/search", response_model=SearchResponse)
async def full_search(request: SearchRequest) -> SearchResponse:
    """
    Runs the complete LangGraph pipeline:
    query_understanding → product_discovery → review_aggregation → 
    authenticity_scoring → explainability
    
    Accepts optional user profile for personalization.
    """
    query = request.query
    profile = request.user_profile
    user_id = request.user_id
    
    if not query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")
    
    try:
        # Build initial state
        initial_state = {
            "user_query": query,
            "user_id": user_id,
            "user_profile": profile.model_dump() if profile else None,
            "parsed_intent": None,
            "candidate_products": [],
            "aggregated_reviews": {},
            "review_sources_used": {},
            "authenticity_scores": {},
            "final_recommendation": None,
            "top_products_ranked": [],
            "needs_clarification": False,
            "clarification_question": None,
            "error": None,
            "current_agent": None,
            "completed_agents": [],
            "conversation_history": [],
        }
        
        # Run the compiled pipeline
        final_state = await pipeline.ainvoke(initial_state)
        
        print(f"\n[BACKEND DEBUG] Pipeline complete. Final state keys: {final_state.keys()}")
        print(f"[BACKEND DEBUG] candidate_products count: {len(final_state.get('candidate_products', []))}")
        print(f"[BACKEND DEBUG] aggregated_reviews count: {len(final_state.get('aggregated_reviews', {}))}")
        print(f"[BACKEND DEBUG] top_products_ranked count: {len(final_state.get('top_products_ranked', []))}")
        
        # Check if clarification is needed — if so, stop here
        if final_state.get("needs_clarification"):
            print(f"[BACKEND DEBUG] Returning clarification response")
            return SearchResponse(
                success=True,
                stage="clarification_needed",
                state=ShoppingState(**final_state),
                error=None,
            )
        
        # Pipeline completed successfully
        print(f"[BACKEND DEBUG] Returning complete response with state")
        response = SearchResponse(
            success=True,
            stage="complete",
            state=ShoppingState(**final_state),
            error=None,
        )
        print(f"[BACKEND DEBUG] Response object: success={response.success}, stage={response.stage}, state_is_none={response.state is None}")
        return response
        
    except Exception as e:
        print(f"[Pipeline Error] {str(e)}")
        import traceback
        traceback.print_exc()
        
        return SearchResponse(
            success=False,
            stage="error",
            state=None,
            error=f"Pipeline failed: {str(e)}"
        )