import os
os.environ.setdefault("GEMINI_API_KEY", "dummy")
os.environ.setdefault("GOOGLE_API_KEY", "dummy")
import asyncio
from agents.query_understanding import QueryUnderstandingAgent

async def main():
    agent = QueryUnderstandingAgent()
    q = "Red shoes under 3000. They should have logo in white too."
    print("Running parse for query:\n", q)
    intent = await agent.parse(q)
    print("Result:\n", intent.json(indent=2))

if __name__ == '__main__':
    asyncio.run(main())
