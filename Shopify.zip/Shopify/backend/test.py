import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv() # This loads the variables from .env
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

print("Available Models for Generation:")
print("-" * 30)

# Loop through and filter models that support generating content
for m in genai.list_models():
    if 'generateContent' in m.supported_generation_methods:
        print(f"Model ID: {m.name}")
        # Note: LangChain usually expects just the ID (e.g., 'gemini-1.5-flash')
        # without the 'models/' prefix.