"""
Authenticity Scoring Agent — Agent 4 in the pipeline

Input  : aggregated_reviews (Dict[product_id → List[review dicts]])
Output : authenticity_scores (Dict[product_id → AuthenticityResult])

Scores each product across 5 dimensions:
  1. Cross-Source Consensus  (weight: 0.30) — core research contribution
  2. Platform Authenticity   (weight: 0.25) — fake pattern detection
  3. Source Credibility      (weight: 0.20) — source trust weighting
  4. Linguistic Authenticity (weight: 0.15) — NLP-based signals
  5. Temporal Authenticity   (weight: 0.10) — time-series anomaly detection
"""

import asyncio
import uuid
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import numpy as np
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate

from config import settings


# ── Constants ──────────────────────────────────────────────────────────────────

DIMENSION_WEIGHTS = {
    "cross_source_consensus":  0.30,
    "platform_authenticity":   0.25,
    "source_credibility":      0.20,
    "linguistic_authenticity": 0.15,
    "temporal_authenticity":   0.10,
}

# Base credibility score by source tier
TIER_CREDIBILITY = {
    "dedicated":  0.90,
    "community":  0.80,
    "video":      0.65,
    "ecommerce":  0.60,
    "blog":       0.45,
}

# Minimum reviews needed per dimension for high confidence
MIN_REVIEWS_HIGH_CONFIDENCE   = 20
MIN_REVIEWS_MEDIUM_CONFIDENCE = 8

# Cosine similarity threshold for near-duplicate detection
DUPLICATE_SIMILARITY_THRESHOLD = 0.88


# ── Data Classes ───────────────────────────────────────────────────────────────

class DimensionScore:
    def __init__(self, score: float, confidence: str, signals: List[str]):
        self.score      = round(score, 1)
        self.confidence = confidence   # high / medium / low
        self.signals    = signals

    def to_dict(self) -> dict:
        return {
            "score":      self.score,
            "confidence": self.confidence,
            "signals":    self.signals,
        }


class AuthenticityResult:
    def __init__(self, product_id: str):
        self.product_id       = product_id
        self.overall_score    = 0.0
        self.dimensions: Dict[str, DimensionScore] = {}
        self.flags: List[str] = []
        self.aspect_consensus: Dict[str, dict] = {}
        self.total_reviews    = 0
        self.sources_count    = 0
        self.review_count_by_source: Dict[str, int] = {}

    def to_dict(self) -> dict:
        return {
            "product_id":             self.product_id,
            "overall_score":          round(self.overall_score, 1),
            "dimensions":             {k: v.to_dict() for k, v in self.dimensions.items()},
            "flags":                  self.flags,
            "aspect_consensus":       self.aspect_consensus,
            "total_reviews":          self.total_reviews,
            "sources_count":          self.sources_count,
            "review_count_by_source": self.review_count_by_source,
        }


# ── Main Agent ─────────────────────────────────────────────────────────────────

class AuthenticityScorer:
    """
    Agent 4 in the pipeline.

    Usage:
        scorer = AuthenticityScorer()
        scores = await scorer.score_all(aggregated_reviews)
        # scores is Dict[product_id → dict]
    """

    def __init__(self):
        # Local embedding model — free, no API calls
        print("[AuthenticityScorer] Loading sentence-transformer model...")
        # Removed: sentence-transformers causes memory corruption in thread executor
        # Using simple string-based duplicate detection instead
        self.embedder = None

        # Setup API key fallback
        self.api_keys = [settings.GEMINI_API_KEY]
        if settings.GEMINI_KEY2:
            self.api_keys.append(settings.GEMINI_KEY2)
        self.current_key_index = 0

        # Gemini for specificity scoring (one call per product)
        self._create_llm()
        print("[AuthenticityScorer] Ready.")

    def _create_llm(self):
        """Create LLM with current API key."""
        current_key = self.api_keys[self.current_key_index]
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            google_api_key=current_key,
            temperature=0,
        )

    # ── Entry Point ────────────────────────────────────────────────────────────

    async def score_all(
        self, aggregated_reviews: Dict[str, List[dict]]
    ) -> Dict[str, dict]:
        """
        Score all products concurrently.
        Returns Dict[product_id → AuthenticityResult.to_dict()]
        """
        tasks = [
            self._score_product(product_id, reviews)
            for product_id, reviews in aggregated_reviews.items()
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        output = {}
        for product_id, result in zip(aggregated_reviews.keys(), results):
            if isinstance(result, Exception):
                print(f"[AuthenticityScorer] Error scoring {product_id}: {result}")
                output[product_id] = self._empty_result(product_id, str(result))
            else:
                output[product_id] = result.to_dict()

        return output

    async def _score_product(
        self, product_id: str, reviews: List[dict]
    ) -> AuthenticityResult:

        result = AuthenticityResult(product_id)
        result.total_reviews = len(reviews)

        if not reviews:
            result.overall_score = 50.0
            for dim in DIMENSION_WEIGHTS:
                result.dimensions[dim] = DimensionScore(
                    50, "low", ["Insufficient reviews for scoring"]
                )
            return result

        # Count by source
        for r in reviews:
            src = r.get("source_platform", "unknown")
            result.review_count_by_source[src] = (
                result.review_count_by_source.get(src, 0) + 1
            )
        result.sources_count = len(result.review_count_by_source)

        # ── Run all 5 dimensions ───────────────────────────────────────────────
        dim1 = self._cross_source_consensus(reviews)
        dim2 = self._platform_authenticity(reviews)
        dim3 = self._source_credibility(reviews)
        dim4 = self._linguistic_authenticity(reviews)  # Simple string-based, no executor needed
        dim5 = self._temporal_authenticity(reviews)
        dim6 = await self._specificity_score(reviews)   # Gemini call

        # Merge linguistic + specificity into one dimension score
        linguistic_combined = DimensionScore(
            score=(dim4.score * 0.6 + dim6.score * 0.4),
            confidence=dim4.confidence,
            signals=dim4.signals + dim6.signals,
        )

        result.dimensions = {
            "cross_source_consensus":  dim1,
            "platform_authenticity":   dim2,
            "source_credibility":      dim3,
            "linguistic_authenticity": linguistic_combined,
            "temporal_authenticity":   dim5,
        }

        # ── Weighted overall score ─────────────────────────────────────────────
        result.overall_score = sum(
            result.dimensions[k].score * w
            for k, w in DIMENSION_WEIGHTS.items()
        )

        # ── Collect all flags across dimensions ────────────────────────────────
        result.flags = [
            sig
            for dim in result.dimensions.values()
            for sig in dim.signals
        ]

        # ── Aspect consensus ───────────────────────────────────────────────────
        result.aspect_consensus = self._aspect_consensus(reviews)

        return result

    # ── Dimension 1: Cross-Source Consensus ───────────────────────────────────

    def _cross_source_consensus(self, reviews: List[dict]) -> DimensionScore:
        """
        Core research contribution.
        Measures agreement across source tiers with different incentive structures.
        High variance across tier means → authenticity is suspect.
        """
        signals = []

        # Group ratings by source tier
        tier_ratings: Dict[str, List[float]] = defaultdict(list)
        for r in reviews:
            if r.get("rating") is not None:
                tier = r.get("source_tier", "ecommerce")
                tier_ratings[tier].append(float(r["rating"]))

        if len(tier_ratings) < 2:
            return DimensionScore(
                score=50,
                confidence="low",
                signals=["Only one source tier available — cannot compute cross-source consensus"],
            )

        # Mean rating per tier
        tier_means = {t: float(np.mean(ratings)) for t, ratings in tier_ratings.items()}

        # Variance across tier means — low variance = high consensus
        means_list = list(tier_means.values())
        inter_tier_variance = float(np.var(means_list))

        # Max possible variance on a 1–5 scale is 4.0 (means at 1 and 5)
        # Normalize variance to 0–1 then invert for score
        normalized_variance = min(inter_tier_variance / 4.0, 1.0)
        base_score = 100.0 * (1.0 - normalized_variance)

        # ── Key signal: e-commerce vs community divergence ─────────────────────
        ecom_mean      = tier_means.get("ecommerce")
        community_mean = tier_means.get("community")

        if ecom_mean is not None and community_mean is not None:
            divergence = abs(ecom_mean - community_mean)
            if divergence >= 2.0:
                signals.append(
                    f"Large divergence: e-commerce avg {ecom_mean:.1f}★ vs "
                    f"community avg {community_mean:.1f}★ (diff: {divergence:.1f})"
                )
                base_score = min(base_score, 40)
            elif divergence >= 1.0:
                signals.append(
                    f"Moderate divergence: e-commerce avg {ecom_mean:.1f}★ vs "
                    f"community avg {community_mean:.1f}★"
                )
                base_score = min(base_score, 65)

        # ── Tier summary for transparency ──────────────────────────────────────
        for tier, mean in tier_means.items():
            signals.append(f"{tier.title()} sources avg: {mean:.1f}★")

        total_rated = sum(len(v) for v in tier_ratings.values())
        confidence  = self._confidence(total_rated)

        return DimensionScore(
            score=max(0, min(100, base_score)),
            confidence=confidence,
            signals=signals,
        )

    # ── Dimension 2: Platform Authenticity ────────────────────────────────────

    def _platform_authenticity(self, reviews: List[dict]) -> DimensionScore:
        """
        Detects fake review patterns in e-commerce reviews:
        - J-curve rating distribution (too many 5-stars)
        - Low verified purchase ratio
        - Suspicious new-account reviewer patterns
        """
        signals = []
        penalties = 0.0

        ecom_reviews = [
            r for r in reviews
            if r.get("source_tier") == "ecommerce"
        ]

        if not ecom_reviews:
            return DimensionScore(
                score=60,
                confidence="low",
                signals=["No e-commerce reviews available for platform authenticity analysis"],
            )

        ratings = [r["rating"] for r in ecom_reviews if r.get("rating") is not None]

        # ── Check 1: Rating distribution (J-curve detection) ──────────────────
        if len(ratings) >= 10:
            five_star_ratio = sum(1 for r in ratings if r >= 4.5) / len(ratings)
            one_star_ratio  = sum(1 for r in ratings if r <= 1.5) / len(ratings)

            if five_star_ratio > 0.75:
                signals.append(
                    f"Suspicious rating distribution: {five_star_ratio:.0%} are 5-star "
                    f"(natural products rarely exceed 60–65%)"
                )
                penalties += 25

            elif five_star_ratio > 0.60:
                signals.append(
                    f"Elevated 5-star ratio: {five_star_ratio:.0%} — slightly above natural range"
                )
                penalties += 10

            # Very few 2–3 star reviews is also suspicious (review suppression)
            mid_ratio = sum(1 for r in ratings if 1.5 < r < 4.5) / len(ratings)
            if mid_ratio < 0.05 and len(ratings) >= 20:
                signals.append(
                    "Very few 2–4 star reviews — possible review suppression or padding"
                )
                penalties += 15

        # ── Check 2: Verified purchase ratio ──────────────────────────────────
        verified = [
            r for r in ecom_reviews
            if r.get("reviewer_metadata", {}).get("verified_purchase")
        ]
        if ecom_reviews:
            verified_ratio = len(verified) / len(ecom_reviews)
            if verified_ratio < 0.30:
                signals.append(
                    f"Low verified purchase ratio: {verified_ratio:.0%} "
                    f"({len(verified)}/{len(ecom_reviews)} reviews)"
                )
                penalties += 20
            elif verified_ratio < 0.50:
                signals.append(
                    f"Moderate verified purchase ratio: {verified_ratio:.0%}"
                )
                penalties += 8

        # ── Check 3: New-account reviewer pattern ─────────────────────────────
        account_ages = [
            r.get("reviewer_metadata", {}).get("account_age_days", None)
            for r in ecom_reviews
        ]
        account_ages = [a for a in account_ages if a is not None]

        if account_ages:
            new_account_ratio = sum(1 for a in account_ages if a < 30) / len(account_ages)
            if new_account_ratio > 0.40:
                signals.append(
                    f"High proportion of new reviewer accounts: "
                    f"{new_account_ratio:.0%} accounts less than 30 days old"
                )
                penalties += 20

        score = max(10, 90 - penalties)
        confidence = self._confidence(len(ecom_reviews))

        return DimensionScore(
            score=score,
            confidence=confidence,
            signals=signals,
        )

    # ── Dimension 3: Source Credibility ───────────────────────────────────────

    def _source_credibility(self, reviews: List[dict]) -> DimensionScore:
        """
        Weighted credibility score based on source tier and reviewer metadata.
        """
        signals = []

        if not reviews:
            return DimensionScore(50, "low", ["No reviews available"])

        weighted_scores = []

        for r in reviews:
            tier = r.get("source_tier", "ecommerce")
            base = TIER_CREDIBILITY.get(tier, 0.5)
            meta = r.get("reviewer_metadata", {})

            # Affiliate disclosure — significant penalty
            if r.get("affiliate_disclosure"):
                base *= 0.60

            # Community-specific adjustments
            if tier == "community":
                karma         = meta.get("karma", 0)
                account_age   = meta.get("account_age_days", 0)
                upvotes       = meta.get("upvotes", 0)

                if account_age < 30:
                    base *= 0.55    # Very new account
                elif account_age > 365:
                    base *= 1.10    # Established account

                if karma > 5000:
                    base *= 1.10
                elif karma < 100:
                    base *= 0.85

                if upvotes > 50:
                    base *= 1.05    # Community validated this review

            # Video-specific adjustments
            if tier == "video":
                likes = meta.get("like_count", 0)
                if likes > 100:
                    base *= 1.10

            weighted_scores.append(min(1.0, base))

        avg_credibility = float(np.mean(weighted_scores)) * 100

        # Flag affiliate-heavy sources
        affiliate_count = sum(1 for r in reviews if r.get("affiliate_disclosure"))
        if affiliate_count > 0:
            signals.append(
                f"{affiliate_count}/{len(reviews)} reviews have affiliate disclosures"
            )

        # Source diversity signal
        tiers_present = set(r.get("source_tier", "ecommerce") for r in reviews)
        signals.append(
            f"Reviews from {len(tiers_present)} source tier(s): {', '.join(sorted(tiers_present))}"
        )

        return DimensionScore(
            score=min(100, avg_credibility),
            confidence=self._confidence(len(reviews)),
            signals=signals,
        )

    # ── Dimension 4a: Linguistic Authenticity (local NLP) ─────────────────────

    def _linguistic_authenticity(self, reviews: List[dict]) -> DimensionScore:
        """
        Simple linguistic authenticity checks without embeddings:
        - Review length distribution analysis
        - Text diversity checking (avoid repeated phrases)
        - Grammar/punctuation patterns
        """
        signals  = []
        penalties = 0.0

        bodies = [r.get("body", "") for r in reviews if len(r.get("body", "")) > 30]

        if len(bodies) < 5:
            return DimensionScore(
                score=65,
                confidence="low",
                signals=["Too few reviews for linguistic analysis"],
            )

        # ── Near-duplicate detection via string matching ─────────────────────
        # Simple approach: look for repeated substrings (copy-paste detection)
        seen_phrases = {}
        duplicate_count = 0
        
        for body in bodies:
            # Extract first 50 chars as a cheap signature
            sig = body[:50].lower()
            if sig in seen_phrases:
                duplicate_count += 1
            seen_phrases[sig] = True
        
        duplicate_ratio = duplicate_count / max(len(bodies), 1)
        
        if duplicate_ratio > 0.30:
            signals.append(
                f"High review similarity detected ({duplicate_ratio:.0%}) — "
                f"possible copy-paste campaign"
            )
            penalties += 25
        elif duplicate_ratio > 0.15:
            signals.append(
                f"Moderate review similarity detected ({duplicate_ratio:.0%})"
            )
            penalties += 10

        # ── Review length distribution ─────────────────────────────────────────
        word_counts = [len(b.split()) for b in bodies]
        avg_words   = float(np.mean(word_counts))
        short_ratio = sum(1 for w in word_counts if w < 10) / len(word_counts)

        if avg_words < 12:
            signals.append(
                f"Reviews are very short on average ({avg_words:.0f} words) — "
                f"low specificity, possible bot-generated content"
            )
            penalties += 20
        elif avg_words < 20:
            signals.append(f"Reviews are brief on average ({avg_words:.0f} words)")
            penalties += 8

        if short_ratio > 0.50:
            signals.append(
                f"{short_ratio:.0%} of reviews are under 10 words — extremely brief"
            )
            penalties += 15

        score = max(10, 85 - penalties)
        return DimensionScore(
            score=score,
            confidence=self._confidence(len(bodies)),
            signals=signals,
        )

    # ── Dimension 4b: Specificity Score (Gemini) ──────────────────────────────

    async def _specificity_score(self, reviews: List[dict]) -> DimensionScore:
        """
        Uses Gemini Flash to assess whether reviews contain specific,
        genuine-sounding experiences vs generic, promotional-sounding text.
        One LLM call per product — samples up to 10 reviews.
        """
        bodies = [r.get("body", "") for r in reviews if len(r.get("body", "")) > 40]
        if not bodies:
            return DimensionScore(60, "low", ["No review text available for specificity analysis"])

        # Sample up to 10 reviews to keep cost low
        sample = bodies[:10]
        sample_text = "\n\n---\n\n".join(
            f"Review {i+1}: {b[:300]}" for i, b in enumerate(sample)
        )

        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert at detecting authentic vs fake product reviews.
Analyze the provided reviews and score their overall SPECIFICITY and AUTHENTICITY.

Genuine reviews tend to:
- Mention specific use cases, durations, comparisons
- Include both positives and negatives
- Reference personal context ("I use this for...")
- Have natural, varied writing styles

Fake/generic reviews tend to:
- Use vague superlatives ("amazing!", "best product ever")
- Have no personal context or specific details
- Be uniformly positive
- Sound promotional or copy-pasted

Return ONLY a JSON object:
{{
    "specificity_score": <0-100>,
    "reasoning": "<one sentence>",
    "red_flags": ["<flag1>", "<flag2>"]
}}"""),
            ("human", f"Analyze these {len(sample)} reviews:\n\n{sample_text}"),
        ])

        try:
            chain  = prompt | self.llm
            result = await chain.ainvoke({})
            text   = result.content.strip()

            # Parse JSON from response
            import json, re
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                data  = json.loads(match.group())
                score = float(data.get("specificity_score", 65))
                flags = data.get("red_flags", [])
                reasoning = data.get("reasoning", "")
                signals = ([f"Specificity analysis: {reasoning}"] if reasoning else []) + flags
                return DimensionScore(
                    score=score,
                    confidence="medium",
                    signals=signals,
                )

        except Exception as e:
            error_msg = str(e)
            print(f"[AuthenticityScorer] Specificity LLM error: {e}")
            
            # Try fallback key if quota error and we have a second key
            if ("429" in error_msg or "quota" in error_msg.lower() or 
                "resource exhausted" in error_msg.lower()) and len(self.api_keys) > 1:
                
                print(f"[AuthenticityScorer] Primary API key quota exhausted, switching to fallback...")
                self.current_key_index = 1
                self._create_llm()
                # Don't retry here; let next product use fallback key

        return DimensionScore(65, "low", ["Specificity analysis unavailable"])

    # ── Dimension 5: Temporal Authenticity ────────────────────────────────────

    def _temporal_authenticity(self, reviews: List[dict]) -> DimensionScore:
        """
        Time-series anomaly detection on review velocity.
        Flags weeks with abnormally high review counts (burst detection).
        """
        signals  = []
        penalties = 0.0

        # Filter reviews with parseable dates
        dated = []
        for r in reviews:
            date_str = r.get("review_date")
            if not date_str:
                continue
            try:
                # Handle both ISO format and date-only strings
                date_str = str(date_str)[:10]
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                dated.append(dt)
            except (ValueError, TypeError):
                continue

        if len(dated) < 8:
            return DimensionScore(
                score=65,
                confidence="low",
                signals=[f"Only {len(dated)} reviews with dates — insufficient for temporal analysis"],
            )

        # ── Group by ISO week ──────────────────────────────────────────────────
        week_counts: Dict[Tuple, int] = defaultdict(int)
        for dt in dated:
            week_key = (dt.isocalendar()[0], dt.isocalendar()[1])
            week_counts[week_key] += 1

        counts = list(week_counts.values())
        mean_weekly = float(np.mean(counts))
        std_weekly  = float(np.std(counts))

        # ── Burst detection: weeks more than 3 std above mean ─────────────────
        threshold       = mean_weekly + 3 * std_weekly
        burst_weeks     = [c for c in counts if c > max(threshold, mean_weekly * 3)]

        if burst_weeks:
            signals.append(
                f"Review burst detected: {len(burst_weeks)} week(s) with abnormally high "
                f"volume (avg {mean_weekly:.1f}/week, burst peaks: {max(burst_weeks)})"
            )
            penalties += min(40, len(burst_weeks) * 15)

        # ── Sudden rating improvement detection ───────────────────────────────
        # Sort reviews by date and look for rating trend reversal
        rated_dated = [
            (dt, r["rating"])
            for dt, r in zip(
                [datetime.strptime(str(r.get("review_date",""))[:10], "%Y-%m-%d")
                 for r in reviews
                 if r.get("review_date") and r.get("rating")],
                [r for r in reviews if r.get("review_date") and r.get("rating")]
            )
        ]

        if len(rated_dated) >= 10:
            rated_dated.sort(key=lambda x: x[0])
            ratings_sorted = [r for _, r in rated_dated]
            n = len(ratings_sorted)
            first_half_mean = float(np.mean(ratings_sorted[:n//2]))
            second_half_mean = float(np.mean(ratings_sorted[n//2:]))

            improvement = second_half_mean - first_half_mean
            if improvement > 1.2:
                signals.append(
                    f"Suspicious rating improvement over time: "
                    f"avg {first_half_mean:.1f}★ early → {second_half_mean:.1f}★ recent "
                    f"(+{improvement:.1f}) — possible seller review manipulation"
                )
                penalties += 20

        score = max(10, 85 - penalties)
        return DimensionScore(
            score=score,
            confidence=self._confidence(len(dated)),
            signals=signals,
        )

    # ── Aspect Consensus ───────────────────────────────────────────────────────

    def _aspect_consensus(self, reviews: List[dict]) -> Dict[str, dict]:
        """
        For each product aspect, measure how much sources agree on sentiment.
        Uses aspect data if already extracted; otherwise skips gracefully.
        """
        aspect_by_tier: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))

        for r in reviews:
            tier    = r.get("source_tier", "ecommerce")
            aspects = r.get("aspects", [])
            for a in aspects:
                if isinstance(a, dict) and a.get("aspect") and a.get("score") is not None:
                    aspect_by_tier[a["aspect"]][tier].append(float(a["score"]))

        if not aspect_by_tier:
            return {}

        result = {}
        for aspect, tier_scores in aspect_by_tier.items():
            all_scores      = [s for scores in tier_scores.values() for s in scores]
            if not all_scores:
                continue

            mean_score      = float(np.mean(all_scores))
            variance        = float(np.var(all_scores))
            consensus_score = max(0.0, 1.0 - variance)
            dominant        = (
                "positive" if mean_score > 0.15
                else "negative" if mean_score < -0.15
                else "neutral"
            )
            source_breakdown = {
                tier: (
                    "positive" if np.mean(scores) > 0.15
                    else "negative" if np.mean(scores) < -0.15
                    else "neutral"
                )
                for tier, scores in tier_scores.items()
            }

            result[aspect] = {
                "consensus_score":      round(consensus_score, 2),
                "dominant_sentiment":   dominant,
                "mean_score":           round(mean_score, 2),
                "source_breakdown":     source_breakdown,
                "total_mentions":       len(all_scores),
            }

        # Sort by number of mentions descending
        return dict(
            sorted(result.items(), key=lambda x: x[1]["total_mentions"], reverse=True)
        )

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _confidence(self, n: int) -> str:
        if n >= MIN_REVIEWS_HIGH_CONFIDENCE:
            return "high"
        elif n >= MIN_REVIEWS_MEDIUM_CONFIDENCE:
            return "medium"
        return "low"

    def _empty_result(self, product_id: str, error: str) -> dict:
        return {
            "product_id":       product_id,
            "overall_score":    50.0,
            "dimensions":       {},
            "flags":            [f"Scoring failed: {error}"],
            "aspect_consensus": {},
            "total_reviews":    0,
            "sources_count":    0,
            "review_count_by_source": {},
        }