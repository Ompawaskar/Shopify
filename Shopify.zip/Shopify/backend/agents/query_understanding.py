import json
import traceback
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from models import ParsedIntent, UserProfile
from config import settings
from typing import Optional


SYSTEM_PROMPT = """You are the Query Understanding Agent for an agentic shopping assistant.

Your job is to convert a user's natural language shopping query into a structured JSON object.
You also have access to the user's profile to fill gaps in the query intelligently.

## Rules
1. Extract ONLY what is clearly stated in the query. Do not over-infer.
2. Use the user profile to fill gaps ONLY when reasonable. Mark any profile-inferred fields in the "inferred" list.
3. If the query is too vague to determine even the product_type, set needs_clarification=true and write a clarification_question.
4. If a budget is mentioned, always set currency to INR unless another currency is clearly mentioned.
5. If the user mentions a brand negatively (e.g. "not boAt", "avoid Samsung"), add it to deal_breakers.
6. Always return valid JSON. No explanation, no markdown, just the JSON object.

## Output Schema
{{
  "product_type": string or null,
  "category": string or null,
  "budget_min": number or null,
  "budget_max": number or null,
  "currency": "INR",
  "budget_flexibility": "strict" or "flexible",
  "use_case": string or null,
  "requirements": [list of strings],
  "deal_breakers": [list of strings],
  "preferred_brands": [list of strings],
  "inferred": [list of field names inferred from profile],
  "needs_clarification": boolean,
  "clarification_question": string or null,
  "comparison_mode": boolean,
  "raw_query": string
}}

## Category Options
electronics, audio, computers, phones, fashion, fitness, home_appliances,
personal_care, books, gaming, kitchen, sports, automotive

## Examples

Query: "best wireless headphones under 5000 for gym, not boAt"
Output: {{
  "product_type": "headphones",
  "category": "audio",
  "budget_min": null,
  "budget_max": 5000,
  "currency": "INR",
  "budget_flexibility": "strict",
  "use_case": "gym",
  "requirements": ["wireless"],
  "deal_breakers": ["boAt"],
  "preferred_brands": [],
  "inferred": [],
  "needs_clarification": false,
  "clarification_question": null,
  "comparison_mode": false,
  "raw_query": "best wireless headphones under 5000 for gym, not boAt"
}}

Query: "I need something for my mom" (with no helpful profile)
Output: {{
  "product_type": null,
  "category": null,
  "budget_min": null,
  "budget_max": null,
  "currency": "INR",
  "budget_flexibility": "flexible",
  "use_case": null,
  "requirements": [],
  "deal_breakers": [],
  "preferred_brands": [],
  "inferred": [],
  "needs_clarification": true,
  "clarification_question": "What kind of product are you looking for for your mom? Any budget in mind?",
  "comparison_mode": false,
  "raw_query": "I need something for my mom"
}}
"""

USER_PROMPT = """## User Query
{query}

## User Profile (use to fill gaps, mark inferred fields)
{profile_str}

Now parse the query and return the JSON object.
"""


class QueryUnderstandingAgent:
    """
    Agent 1 in the pipeline.
    Input  : raw user query + optional user profile
    Output : ParsedIntent (structured object ready for Product Discovery Agent)
    """

    def __init__(self):
        self.api_keys = [settings.GEMINI_API_KEY]
        if settings.GEMINI_KEY2:
            self.api_keys.append(settings.GEMINI_KEY2)
        self.current_key_index = 0
        
        self._create_chain()

    def _create_chain(self):
        """Create the LLM chain with the current API key."""
        current_key = self.api_keys[self.current_key_index]
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            google_api_key=current_key,
            temperature=0,
        )

        self.parser = JsonOutputParser(pydantic_object=ParsedIntent)
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT),
            ("human", USER_PROMPT),
        ])
        self.chain = self.prompt | self.llm | self.parser

    async def _try_with_fallback(self, invoke_fn):
        """Try invoking with fallback to secondary API key on quota errors."""
        try:
            return await invoke_fn()
        except Exception as e:
            error_msg = str(e)
            if ("429" in error_msg or "quota" in error_msg.lower() or 
                "resource exhausted" in error_msg.lower()) and len(self.api_keys) > 1:
                
                print(f"[QueryUnderstandingAgent] Primary API key quota exhausted, switching to fallback...")
                self.current_key_index = 1
                self._create_chain()
                return await invoke_fn()
            raise

    async def parse(self, query: str, profile: Optional[UserProfile] = None) -> ParsedIntent:
        """
        Main entry point. Called by the Orchestrator or directly via API.
        Returns ParsedIntent ready to pass to the next agent.
        """
        profile_str = self._format_profile(profile)

        async def invoke_chain():
            result = await self.chain.ainvoke({
                "query": query,
                "profile_str": profile_str,
            })

            # Ensure raw_query is always set
            if isinstance(result, dict):
                result["raw_query"] = query
                return ParsedIntent(**result)
            
            result.raw_query = query
            return result

        try:
            return await self._try_with_fallback(invoke_chain)

        except Exception as e:
            # Log full traceback for debugging (visible in server logs)
            print("[QueryUnderstandingAgent] Exception while parsing:", str(e))
            print(traceback.format_exc())

            # Fallback: return minimal intent so pipeline doesn't break.
            # Include the exception message in the clarification to aid debugging.
            return ParsedIntent(
                raw_query=query,
                needs_clarification=True,
                clarification_question=(
                    "Could you tell me more about what you're looking for?"
                    + f" (debug: parse error: {str(e)[:200]})"
                ),
            )

    def _format_profile(self, profile: Optional[UserProfile]) -> str:
        if not profile:
            return "No user profile available."
        return f"""
Name: {profile.name}
Age: {profile.age}
Gender: {profile.gender}
Location: {profile.location}
Budget Style: {profile.budget_style}
Preferred Categories: {', '.join(profile.preferred_categories)}
Preferred Brands: {', '.join(profile.preferred_brands) or 'None'}
Avoided Brands: {', '.join(profile.avoided_brands) or 'None'}
"""