import uuid
from serpapi import GoogleSearch
from config import settings
from models import ParsedIntent, Product
from typing import List


# Brands to platform mapping for cleaner display
PLATFORM_MAP = {
    "amazon": "amazon.in",
    "flipkart": "flipkart.com",
    "croma": "croma.com",
    "reliance": "reliancedigital.in",
    "myntra": "myntra.com",
    "meesho": "meesho.com",
    "tatacliq": "tatacliq.com",
}

# Platform trust scores for ranking (higher = more trusted)
PLATFORM_TRUST = {
    "amazon.in": 1.0,
    "flipkart.com": 0.95,
    "croma.com": 0.90,
    "reliancedigital.in": 0.85,
    "tatacliq.com": 0.85,
    "myntra.com": 0.80,
    "meesho.com": 0.65,
}


class ProductDiscoveryAgent:
    """
    Agent 2 in the pipeline.
    Input  : ParsedIntent from Query Understanding Agent
    Output : List[Product] — top 10 ranked products, ready for Review Aggregation Agent
    """

    def __init__(self):
        self.api_key = settings.SERPAPI_KEY

    async def discover(self, intent: ParsedIntent, profile = None) -> List[Product]:
        """
        Main entry point. Called by Orchestrator with ParsedIntent and optional UserProfile.
        Returns ranked product list personalized to user profile (gender, preferences).
        """
        # Step 1 — Build optimized search query
        query = self._build_query(intent)

        # Step 2 — Fetch from Google Shopping via SerpAPI
        raw_results = self._fetch_products(query, intent)

        # Step 3 — Normalize to Product schema
        products = self._normalize(raw_results)

        # Step 4 — Filter by intent constraints and user profile
        products = self._filter(products, intent, profile)

        # Step 5 — Rank and return top 10
        products = self._rank(products, intent, profile)

        return products[:10]

    # ── Step 1: Query Builder ──────────────────────────────────────────────────

    def _build_query(self, intent: ParsedIntent) -> str:
        parts = []

        # Requirements first (wireless, waterproof, etc.)
        if intent.requirements:
            parts.extend(intent.requirements)

        # Product type
        if intent.product_type:
            parts.append(intent.product_type)

        # Use case
        if intent.use_case:
            parts.append(f"for {intent.use_case}")

        # Budget
        if intent.budget_max:
            parts.append(f"under {int(intent.budget_max)} rupees")

        # Preferred brands
        if intent.preferred_brands:
            parts.append(f"by {' or '.join(intent.preferred_brands)}")

        query = " ".join(parts)

        # Fallback to raw query if parsing failed
        if not query.strip():
            query = intent.raw_query

        return query

    # ── Step 2: SerpAPI Fetch ──────────────────────────────────────────────────

    def _fetch_products(self, query: str, intent: ParsedIntent) -> list:
        # Prefer the Amazon engine to obtain ASINs; fallback to Google Shopping
        # Build common params
        params_amazon = {
            "engine": "amazon",
            "k": query,
            "api_key": self.api_key,
            "amazon_domain": "amazon.com",
            "device": "desktop",
        }

        # price filters only supported on some engines — add when present
        if intent.budget_max:
            params_amazon["price_max"] = int(intent.budget_max)
        if intent.budget_min:
            params_amazon["price_min"] = int(intent.budget_min)

        try:
            search = GoogleSearch(params_amazon)
            results = search.get_dict()

            # SerpApi may return product_results, organic_results, or shopping_results
            if "product_results" in results:
                return results.get("product_results", [])
            if "organic_results" in results:
                return results.get("organic_results", [])
            if "search_results" in results:
                return results.get("search_results", [])
            if "shopping_results" in results:
                return results.get("shopping_results", [])

        except Exception as e:
            print(f"[ProductDiscoveryAgent] SerpAPI (amazon) error: {e}")

        # Fallback: Google Shopping engine (older behavior)
        params_gs = {
            "engine": "google_shopping",
            "q": query,
            "api_key": self.api_key,
            "gl": "in",              # India
            "hl": "en",
            "num": 20,
        }

        if intent.budget_max:
            params_gs["price_max"] = int(intent.budget_max)
        if intent.budget_min:
            params_gs["price_min"] = int(intent.budget_min)

        try:
            search = GoogleSearch(params_gs)
            results = search.get_dict()
            return results.get("shopping_results", [])
        except Exception as e:
            print(f"[ProductDiscoveryAgent] SerpAPI (google_shopping) error: {e}")
            return []

    # ── Step 3: Normalize ──────────────────────────────────────────────────────

    def _normalize(self, raw: list) -> List[Product]:
        products = []
        for item in raw:
            try:
                # Extract platform from source string
                source = item.get("source", "").lower() if isinstance(item, dict) else ""
                platform = self._extract_platform(source)

                # Extract brand from title
                title = item.get("title", "")
                brand = self._extract_brand(title)

                # Parse price — SerpAPI returns as string e.g. "₹4,999"
                price = self._parse_price(item.get("price", "0"))

                # Extract ASIN if present (amazon engine)
                asin = None
                serpapi_link = None
                if isinstance(item, dict):
                    asin = item.get("asin") or item.get("product_id")
                    serpapi_link = item.get("serpapi_link") or item.get("serpapi_link")

                product = Product(
                    id=str(uuid.uuid4()),
                    name=title,
                    brand=brand,
                    price=price,
                    original_price=self._parse_price(item.get("original_price", "0")) or None,
                    currency="INR",
                    platform=platform,
                    url=item.get("link") or item.get("product_link", ""),
                    asin=asin,
                    serpapi_link=serpapi_link,
                    image_url=item.get("thumbnail", ""),
                    rating=float(item.get("rating", 0)) or None,
                    review_count=int(item.get("reviews", 0)) or None,
                    source="google_shopping",
                )
                products.append(product)
            except Exception as e:
                print(f"[ProductDiscoveryAgent] Normalization error for item: {e}")
                continue

        return products

    # ── Step 4: Filter ─────────────────────────────────────────────────────────

    def _filter(self, products: List[Product], intent: ParsedIntent, profile = None) -> List[Product]:
        filtered = []

        for p in products:
            # Hard filter: budget
            if intent.budget_max and p.price > intent.budget_max * 1.05:  # 5% tolerance
                continue

            # Hard filter: deal breaker brands
            if intent.deal_breakers:
                brand_lower = p.brand.lower()
                name_lower = p.name.lower()
                skip = False
                for breaker in intent.deal_breakers:
                    if breaker.lower() in brand_lower or breaker.lower() in name_lower:
                        skip = True
                        break
                if skip:
                    continue

            # Gender-based filtering for fashion/footwear
            if profile and profile.gender and intent.category in ["fashion", "audio", "fitness"]:
                product_name_lower = p.name.lower()
                gender = profile.gender.lower()
                # Filter out products for opposite gender
                if gender == "male" and ("women" in product_name_lower or "ladies" in product_name_lower or "girl" in product_name_lower):
                    continue
                if gender == "female" and (" men" in product_name_lower or " men's" in product_name_lower or "men's" in product_name_lower):
                    continue
            
            # Soft filter: user's avoided brands
            if profile and profile.avoided_brands:
                brand_lower = p.brand.lower()
                name_lower = p.name.lower()
                skip = False
                for avoided in profile.avoided_brands:
                    if avoided.lower() in brand_lower or avoided.lower() in name_lower:
                        skip = True
                        break
                if skip:
                    continue

            filtered.append(p)

        return filtered

    # ── Step 5: Rank ───────────────────────────────────────────────────────────

    def _rank(self, products: List[Product], intent: ParsedIntent, profile = None) -> List[Product]:
        def score(p: Product) -> float:
            total = 0.0

            # Platform trust (0–1) → weight 0.25
            trust = PLATFORM_TRUST.get(p.platform, 0.5)
            total += trust * 0.25

            # Rating (0–5 normalized to 0–1) → weight 0.25
            if p.rating:
                total += (p.rating / 5.0) * 0.25

            # Price fit → weight 0.3
            # Closer to budget max = better fit (user wants best within budget)
            if intent.budget_max and p.price > 0:
                price_ratio = p.price / intent.budget_max
                # Sweet spot: 0.7–1.0 of budget
                if 0.7 <= price_ratio <= 1.0:
                    total += 0.3
                elif price_ratio < 0.7:
                    total += 0.15   # Too cheap, might not meet requirements
            else:
                total += 0.15       # No budget specified, neutral score

            # Preferred brand bonus (from intent) → weight 0.1
            if intent.preferred_brands:
                for brand in intent.preferred_brands:
                    if brand.lower() in p.brand.lower():
                        total += 0.1
                        break

            # User profile preferred brands bonus → weight 0.1
            if profile and profile.preferred_brands:
                for brand in profile.preferred_brands:
                    if brand.lower() in p.brand.lower():
                        total += 0.1
                        break

            return total

        return sorted(products, key=score, reverse=True)

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _extract_platform(self, source: str) -> str:
        for key, platform in PLATFORM_MAP.items():
            if key in source:
                return platform
        # Return cleaned source as fallback
        return source.split()[0] if source else "unknown"

    def _extract_brand(self, title: str) -> str:
        # First word of title is usually the brand
        return title.split()[0] if title else "Unknown"

    def _parse_price(self, price_str: str) -> float:
        if not price_str:
            return 0.0
        # Remove currency symbols, commas, spaces
        cleaned = str(price_str).replace("₹", "").replace(",", "").replace(" ", "").strip()
        try:
            return float(cleaned)
        except ValueError:
            return 0.0