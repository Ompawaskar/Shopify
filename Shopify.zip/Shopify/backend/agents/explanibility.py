"""
Explainability Agent — Agent 5 (Final) in the pipeline

Input  : parsed_intent, candidate_products, authenticity_scores,
         aggregated_reviews, review_sources_used  (all from ShoppingState)
Output : final_recommendation (structured dict) + top_products_ranked

This agent synthesizes everything upstream into a human-readable,
sourced recommendation that explains WHAT to buy, WHY, and HOW MUCH
to trust that recommendation.

Uses Gemini 1.5 Pro — the one place in the pipeline where we use the
smarter model since this is the user-facing output.
"""

import json
import re
from typing import Dict, List, Optional

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate

from config import settings


# ── Trust verdict thresholds ───────────────────────────────────────────────────
TRUST_HIGH   = 70
TRUST_MEDIUM = 45


class ExplainabilityAgent:
    """
    Agent 5 in the pipeline.

    Usage:
        agent = ExplainabilityAgent()
        result = await agent.explain(
            parsed_intent=state["parsed_intent"],
            products=state["candidate_products"],
            authenticity_scores=state["authenticity_scores"],
            aggregated_reviews=state["aggregated_reviews"],
            review_sources_used=state["review_sources_used"],
        )
        # result → dict with top_pick, product_summaries, sources_summary etc.
    """

    def __init__(self):
        # Setup API key fallback
        self.api_keys = [settings.GEMINI_API_KEY]
        if settings.GEMINI_KEY2:
            self.api_keys.append(settings.GEMINI_KEY2)
        self.current_key_index = 0
        
        # Use for final user-facing output
        self._create_llm()

    def _create_llm(self):
        """Create LLM with current API key."""
        current_key = self.api_keys[self.current_key_index]
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            google_api_key=current_key,
            temperature=0.3,      # Slight creativity for natural language output
        )

    # ── Entry Point ────────────────────────────────────────────────────────────

    async def explain(
        self,
        parsed_intent: dict,
        products: List[dict],
        authenticity_scores: Dict[str, dict],
        aggregated_reviews: Dict[str, List[dict]],
        review_sources_used: Dict[str, List[str]],
    ) -> dict:
        """
        Main entry point. Called by pipeline node or directly.
        Returns structured recommendation dict.
        """

        if not products:
            return self._empty_result("No products found matching your criteria.")

        # Step 1 — Rank products by authenticity score
        ranked = self._rank_products(products, authenticity_scores)

        # Step 2 — Build structured summaries per product (rule-based, no LLM)
        product_summaries = [
            self._build_product_summary(p, authenticity_scores, aggregated_reviews)
            for p in ranked[:5]    # Top 5 only
        ]

        # Step 3 — Build sources summary
        sources_summary = self._build_sources_summary(
            review_sources_used, aggregated_reviews
        )

        # Step 4 — LLM call for natural language top-pick reasoning
        top_pick_reasoning = await self._generate_top_pick_reasoning(
            parsed_intent=parsed_intent,
            top_products=ranked[:3],
            summaries=product_summaries[:3],
            authenticity_scores=authenticity_scores,
            aggregated_reviews=aggregated_reviews,
        )

        # Step 5 — Assemble final result
        top = ranked[0]
        top_score = authenticity_scores.get(top["id"], {}).get("overall_score", 50)

        result = {
            "top_pick": {
                "product_id":   top["id"],
                "product_name": top["name"],
                "price":        top["price"],
                "platform":     top["platform"],
                "url":          top.get("serpapi_link") or top.get("url", ""),
                "image_url":    top.get("image_url", ""),
                "reasoning":    top_pick_reasoning.get("reasoning", ""),
                "confidence":   self._confidence_label(top_score),
                "one_liner":    top_pick_reasoning.get("one_liner", ""),
            },
            "product_summaries":  product_summaries,
            "top_products_ranked": ranked,
            "sources_summary":    sources_summary,
            "overall_confidence": self._overall_confidence(authenticity_scores, products),
            "disclaimer":         self._build_disclaimer(authenticity_scores, products),
            "query_understood_as": self._summarise_intent(parsed_intent),
        }

        return result

    # ── Step 1: Rank Products ──────────────────────────────────────────────────

    def _rank_products(
        self, products: List[dict], scores: Dict[str, dict]
    ) -> List[dict]:
        """
        Rank products by combined authenticity score + rating.
        Products with no authenticity data fall to the bottom.
        """
        def rank_key(p: dict) -> float:
            auth  = scores.get(p["id"], {}).get("overall_score", 40)
            stars = (p.get("rating") or 3.0) / 5.0 * 25    # Max 25 points from rating
            return auth * 0.75 + stars

        return sorted(products, key=rank_key, reverse=True)

    # ── Step 2: Per-Product Summary (rule-based) ───────────────────────────────

    def _build_product_summary(
        self,
        product: dict,
        scores: Dict[str, dict],
        reviews: Dict[str, List[dict]],
    ) -> dict:
        pid        = product["id"]
        auth       = scores.get(pid, {})
        dimensions = auth.get("dimensions", {})
        flags      = auth.get("flags", [])
        overall    = auth.get("overall_score", 50)

        # Trust verdict
        if overall >= TRUST_HIGH:
            verdict = "Trustworthy"
        elif overall >= TRUST_MEDIUM:
            verdict = "Mixed Signals"
        else:
            verdict = "Suspicious"

        # Key positives — from high-consensus aspects and positive flags
        positives = self._extract_positives(dimensions, auth.get("aspect_consensus", {}))

        # Key concerns — from flags and low-consensus aspects
        concerns = self._extract_concerns(flags, auth.get("aspect_consensus", {}))

        # Authenticity note — most important single flag
        auth_note = self._most_important_flag(flags, overall)

        # Review count breakdown
        review_counts = auth.get("review_count_by_source", {})
        total_reviews = auth.get("total_reviews", 0)

        # Dimension scores for display
        dim_scores = {
            k: {
                "score":      v.get("score", 0),
                "confidence": v.get("confidence", "low"),
            }
            for k, v in dimensions.items()
        }

        return {
            "product_id":       pid,
            "product_name":     product["name"],
            "price":            product["price"],
            "platform":         product["platform"],
            "overall_score":    overall,
            "trust_verdict":    verdict,
            "key_positives":    positives[:3],
            "key_concerns":     concerns[:3],
            "authenticity_note": auth_note,
            "dimension_scores": dim_scores,
            "review_breakdown": review_counts,
            "total_reviews":    total_reviews,
        }

    def _extract_positives(self, dimensions: dict, aspect_consensus: dict) -> List[str]:
        positives = []

        # High cross-source consensus is itself a positive
        css = dimensions.get("cross_source_consensus", {})
        if css.get("score", 0) >= 75:
            positives.append("Strong agreement across independent review sources")

        # High source credibility
        sc = dimensions.get("source_credibility", {})
        if sc.get("score", 0) >= 75:
            positives.append("Reviews come from credible, established sources")

        # Positive aspect consensus
        for aspect, data in aspect_consensus.items():
            if (data.get("dominant_sentiment") == "positive"
                    and data.get("consensus_score", 0) >= 0.75):
                positives.append(
                    f"{aspect.replace('_', ' ').title()} praised consistently "
                    f"across sources ({data['consensus_score']:.0%} agreement)"
                )

        return positives if positives else ["Insufficient data for positive signals"]

    def _extract_concerns(self, flags: List[str], aspect_consensus: dict) -> List[str]:
        concerns = []

        # Filter flags that indicate problems
        concern_keywords = [
            "divergence", "suspicious", "burst", "duplicate",
            "low verified", "inflated", "manipulation", "new account",
            "affiliate", "short", "improvement"
        ]
        for flag in flags:
            if any(kw in flag.lower() for kw in concern_keywords):
                concerns.append(flag)

        # Negative aspect consensus
        for aspect, data in aspect_consensus.items():
            if (data.get("dominant_sentiment") == "negative"
                    and data.get("consensus_score", 0) >= 0.70):
                concerns.append(
                    f"{aspect.replace('_', ' ').title()} consistently flagged "
                    f"as negative across sources"
                )

        return concerns if concerns else []

    def _most_important_flag(self, flags: List[str], overall_score: float) -> str:
        if not flags:
            if overall_score >= TRUST_HIGH:
                return "No major authenticity concerns detected."
            return "Limited review data available — score based on partial information."

        # Prioritise divergence and distribution flags as most important
        priority_keywords = ["divergence", "5-star", "burst", "duplicate", "manipulation"]
        for flag in flags:
            if any(kw in flag.lower() for kw in priority_keywords):
                return flag

        return flags[0]

    # ── Step 3: Sources Summary ────────────────────────────────────────────────

    def _build_sources_summary(
        self,
        sources_used: Dict[str, List[str]],
        reviews: Dict[str, List[dict]],
    ) -> str:
        all_sources: set = set()
        for srcs in sources_used.values():
            all_sources.update(srcs)

        total_reviews = sum(len(v) for v in reviews.values())
        total_products = len(reviews)

        if not all_sources:
            return "No external review sources were available."

        source_labels = {
            "amazon":   "Amazon",
            "flipkart": "Flipkart",
            "reddit":   "Reddit",
            "youtube":  "YouTube",
            "blog":     "review blogs",
        }
        named = [source_labels.get(s, s.title()) for s in sorted(all_sources)]

        return (
            f"Analyzed {total_reviews} reviews across {len(all_sources)} source(s) "
            f"— {', '.join(named)} — for {total_products} product(s)."
        )

    # ── Step 4: LLM — Top Pick Reasoning ──────────────────────────────────────

    async def _generate_top_pick_reasoning(
        self,
        parsed_intent: dict,
        top_products: List[dict],
        summaries: List[dict],
        authenticity_scores: Dict[str, dict],
        aggregated_reviews: Dict[str, List[dict]],
    ) -> dict:
        """
        One Gemini Pro call to generate the natural language recommendation.
        Uses structured prompt with all authenticity data baked in.
        """

        # Build a compact data packet for the prompt
        products_data = []
        for p, s in zip(top_products, summaries):
            pid      = p["id"]
            auth     = authenticity_scores.get(pid, {})
            r_sample = self._sample_reviews(aggregated_reviews.get(pid, []))

            products_data.append({
                "name":             p["name"],
                "price":            f"₹{p['price']:,.0f}",
                "platform":         p["platform"],
                "asin":             p.get("asin"),
                "serpapi_link":     p.get("serpapi_link"),
                "overall_score":    auth.get("overall_score", 50),
                "trust_verdict":    s["trust_verdict"],
                "key_positives":    s["key_positives"],
                "key_concerns":     s["key_concerns"],
                "authenticity_note": s["authenticity_note"],
                "review_samples":   r_sample,
                "sources":          list(auth.get("review_count_by_source", {}).keys()),
            })

        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert shopping advisor with access to cross-platform 
review authenticity data. Your job is to give honest, specific recommendations 
backed by the authenticity analysis provided.

Rules:
- Be direct and specific. Cite actual data points from the analysis.
- Mention source divergence when it exists — this is the most important signal.
- Acknowledge uncertainty honestly when confidence is low.
- Never sound like a sales pitch. Sound like a trusted friend with data.
- Keep reasoning concise — 3-5 sentences max.
- The one_liner must be under 15 words.

Return ONLY valid JSON:
{{
    "one_liner": "<under 15 words capturing the recommendation>",
    "reasoning": "<3-5 sentences with specific data citations>"
}}"""),
            ("human", """User is looking for: {intent_summary}

Top {n} products being considered:
{products_json}

Based on the authenticity analysis above, write the recommendation."""),
        ])

        try:
            chain  = prompt | self.llm
            result = await chain.ainvoke({
                "intent_summary": self._summarise_intent(parsed_intent),
                "n":              len(products_data),
                "products_json":  json.dumps(products_data, indent=2),
            })

            text  = result.content.strip()
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                return json.loads(match.group())

        except Exception as e:
            error_msg = str(e)
            print(f"[ExplainabilityAgent] LLM error: {e}")
            
            # Try fallback key if quota error and we have a second key
            if ("429" in error_msg or "quota" in error_msg.lower() or 
                "resource exhausted" in error_msg.lower()) and len(self.api_keys) > 1:
                
                print(f"[ExplainabilityAgent] Primary API key quota exhausted, switching to fallback...")
                self.current_key_index = 1
                self._create_llm()

        # Fallback if LLM fails
        top = top_products[0] if top_products else {}
        score = authenticity_scores.get(top.get("id",""), {}).get("overall_score", 50)
        return {
            "one_liner": f"{top.get('name','—')} — best authenticity score of the group.",
            "reasoning": (
                f"{top.get('name','—')} at ₹{top.get('price',0):,.0f} has an authenticity "
                f"score of {score:.0f}/100. "
                f"{summaries[0]['authenticity_note'] if summaries else ''}"
            ),
        }

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _sample_reviews(self, reviews: List[dict], n: int = 4) -> List[str]:
        """
        Pick a representative sample of reviews across source tiers.
        Prefer reviews with actual text content.
        """
        by_tier: Dict[str, List[dict]] = {}
        for r in reviews:
            tier = r.get("source_tier", "ecommerce")
            by_tier.setdefault(tier, []).append(r)

        samples = []
        for tier, tier_reviews in by_tier.items():
            # Pick the longest review from each tier as most informative
            best = max(
                tier_reviews,
                key=lambda x: len(x.get("body", "")),
                default=None,
            )
            if best and best.get("body"):
                excerpt = best["body"][:200].replace("\n", " ")
                samples.append(f"[{tier}] {excerpt}...")
            if len(samples) >= n:
                break

        return samples

    def _summarise_intent(self, intent: dict) -> str:
        if not intent:
            return "a product"
        parts = []
        if intent.get("requirements"):
            parts.extend(intent["requirements"])
        if intent.get("product_type"):
            parts.append(intent["product_type"])
        if intent.get("use_case"):
            parts.append(f"for {intent['use_case']}")
        if intent.get("budget_max"):
            parts.append(f"under ₹{intent['budget_max']:,.0f}")
        if intent.get("deal_breakers"):
            parts.append(f"(not {', '.join(intent['deal_breakers'])})")
        return " ".join(parts) or intent.get("raw_query", "a product")

    def _confidence_label(self, score: float) -> str:
        if score >= TRUST_HIGH:
            return "high"
        elif score >= TRUST_MEDIUM:
            return "medium"
        return "low"

    def _overall_confidence(
        self, scores: Dict[str, dict], products: List[dict]
    ) -> str:
        if not scores:
            return "low"
        total_reviews = sum(s.get("total_reviews", 0) for s in scores.values())
        sources_count = max((s.get("sources_count", 0) for s in scores.values()), default=0)

        if total_reviews >= 30 and sources_count >= 2:
            return "high"
        elif total_reviews >= 10 or sources_count >= 2:
            return "medium"
        return "low"

    def _build_disclaimer(
        self, scores: Dict[str, dict], products: List[dict]
    ) -> Optional[str]:
        disclaimers = []

        total_reviews = sum(s.get("total_reviews", 0) for s in scores.values())
        if total_reviews < 15:
            disclaimers.append(
                "Limited review data available — we recommend checking Reddit "
                "and YouTube manually before purchase."
            )

        max_sources = max(
            (s.get("sources_count", 0) for s in scores.values()), default=0
        )
        if max_sources < 2:
            disclaimers.append(
                "Reviews only available from one source type — "
                "cross-source consensus could not be computed."
            )

        suspicious = [
            s for s in scores.values()
            if s.get("overall_score", 100) < TRUST_MEDIUM
        ]
        if suspicious:
            disclaimers.append(
                f"{len(suspicious)} product(s) have low authenticity scores — "
                "exercise caution and verify reviews independently."
            )

        return " ".join(disclaimers) if disclaimers else None

    def _empty_result(self, message: str) -> dict:
        return {
            "top_pick":           None,
            "product_summaries":  [],
            "top_products_ranked": [],
            "sources_summary":    message,
            "overall_confidence": "low",
            "disclaimer":         None,
            "query_understood_as": "",
        }