import uuid
import asyncio
import httpx
import re

from bs4 import BeautifulSoup
from youtube_transcript_api import YouTubeTranscriptApi
from transformers import pipeline
from googleapiclient.discovery import build

from models import NormalizedReview, SourceTier
from config import settings


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
    ),
    "Accept-Language": "en-IN,en;q=0.9"
}


class ReviewAggregationAgent:

    def __init__(self):

        self.http = httpx.AsyncClient(timeout=25, headers=HEADERS)

        self.sentiment = pipeline(
            "sentiment-analysis",
            model="distilbert-base-uncased-finetuned-sst-2-english"
        )

        self.youtube = build(
            "youtube",
            "v3",
            developerKey=settings.YOUTUBE_API_KEY
        )

        self.transcript_api = YouTubeTranscriptApi()

    # ─────────────────────────────────────────────

    async def aggregate(self, products):

        tasks = [self._aggregate_product(p) for p in products]

        results = await asyncio.gather(*tasks)

        return {
            product["id"]: reviews
            for product, reviews in zip(products, results)
        }

    # ─────────────────────────────────────────────

    async def _aggregate_product(self, product):

        product_name = product["name"]
        product_id = product["id"]

        tasks = [
            self._fetch_amazon_reviews(product),

            self._fetch_reddit_reviews(product_id, product_name),

            self._fetch_flipkart_reviews(product_id, product_name),

            self._fetch_youtube_reviews(product_id, product_name),
        ]

        results = await asyncio.gather(*tasks)

        reviews = []

        for r in results:
            reviews.extend(r)

        print(f"[ReviewAgg] {product_name}: collected {len(reviews)} reviews")

        return [r.model_dump() for r in reviews]

    # ─────────────────────────────────────────────
    # AMAZON FIXED
    # ─────────────────────────────────────────────

    async def _fetch_amazon_reviews(self, product):

        product_id = product.get("id")
        product_name = product.get("name")

        # Prefer ASIN returned from ProductDiscovery
        asin = product.get("asin")

        if not asin:
            asin = await self._get_amazon_asin(product_name)

        if not asin:
            return []

        # Determine amazon domain from product.platform if present
        amazon_domain = "amazon.com"
        platform = product.get("platform", "")
        if platform and "amazon" in platform:
            # platform like amazon.in or amazon.com
            amazon_domain = platform

        params = {
            "engine": "amazon_reviews",
            "asin": asin,
            "amazon_domain": amazon_domain,
            "api_key": settings.SERPAPI_KEY,
            "sort_by": "helpful"
        }

        try:
            resp = await self.http.get(
                "https://serpapi.com/search",
                params=params
            )

            data = resp.json()

        except Exception as e:
            print("[ReviewAgg] Amazon reviews error:", e)
            return []

        reviews = []

        for r in data.get("reviews", []):
            body = r.get("body")
            if not self._is_valid_review(body):
                continue

            reviews.append(
                NormalizedReview(
                    id=str(uuid.uuid4()),
                    product_id=product_id,
                    source_platform="amazon",
                    source_tier=SourceTier.ECOMMERCE,
                    source_url=r.get("link"),
                    rating=float(r.get("rating", 0)) if r.get("rating") is not None else None,
                    body=body,
                    helpful_votes=r.get("helpful_votes", 0),
                    reviewer_metadata={
                        "verified_purchase": r.get("verified_purchase", False)
                    }
                )
            )

        print("[ReviewAgg] Amazon:", len(reviews))
        return reviews

    async def _get_amazon_asin(self, product_name):

        params = {
            "engine": "amazon",
            "q": product_name,
            "amazon_domain": "amazon.in",
            "api_key": settings.SERPAPI_KEY
        }

        try:

            resp = await self.http.get(
                "https://serpapi.com/search",
                params=params
            )

            data = resp.json()

        except Exception:

            return None

        results = data.get("organic_results", [])

        if not results:
            return None

        return results[0].get("asin")

    # ─────────────────────────────────────────────
    # REDDIT FIXED
    # ─────────────────────────────────────────────

    async def _fetch_reddit_reviews(self, product_id, product_name):

        params = {
            "engine": "google",
            "q": f"{product_name} site:reddit.com",
            "api_key": settings.SERPAPI_KEY,
            "num": 10
        }

        try:

            resp = await self.http.get(
                "https://serpapi.com/search",
                params=params
            )

            data = resp.json()

        except Exception:

            return []

        reviews = []

        for result in data.get("organic_results", []):

            url = result.get("link")

            if not url:
                continue

            url = url.replace("www.reddit.com", "old.reddit.com")

            try:

                page = await self.http.get(url)

                soup = BeautifulSoup(page.text, "html.parser")

                text = soup.get_text()

                if not self._is_valid_review(text):
                    continue

                reviews.append(

                    NormalizedReview(

                        id=str(uuid.uuid4()),
                        product_id=product_id,

                        source_platform="reddit",

                        source_tier=SourceTier.COMMUNITY,

                        source_url=url,

                        body=text[:2000],

                        rating=await self._infer_rating(text)
                    )
                )

            except Exception:

                continue

        print("[ReviewAgg] Reddit:", len(reviews))

        return reviews

    # ─────────────────────────────────────────────
    # FLIPKART FIXED
    # ─────────────────────────────────────────────

    async def _fetch_flipkart_reviews(self, product_id, product_name):

        try:

            search_url = f"https://www.flipkart.com/search?q={product_name.replace(' ','+')}"

            resp = await self.http.get(search_url)

            soup = BeautifulSoup(resp.text, "html.parser")

            product_link = soup.select_one("a[href*='/p/']")

            if not product_link:
                return []

            url = "https://www.flipkart.com" + product_link["href"]

            review_url = url.split("?")[0] + "&page=1"

            resp = await self.http.get(review_url)

            soup = BeautifulSoup(resp.text, "html.parser")

        except Exception:

            return []

        reviews = []

        for block in soup.select("div.t-ZTKy"):

            body = block.get_text()

            if not self._is_valid_review(body):
                continue

            reviews.append(

                NormalizedReview(

                    id=str(uuid.uuid4()),

                    product_id=product_id,

                    source_platform="flipkart",

                    source_tier=SourceTier.ECOMMERCE,

                    body=body,

                    rating=await self._infer_rating(body)
                )
            )

        print("[ReviewAgg] Flipkart:", len(reviews))

        return reviews

    # ─────────────────────────────────────────────
    # YOUTUBE FIXED (transcript + fallback comments)
    # ─────────────────────────────────────────────

    async def _fetch_youtube_reviews(self, product_id, product_name):

        try:

            search = self.youtube.search().list(

                q=f"{product_name} review",

                part="snippet",

                type="video",

                maxResults=10

            ).execute()

        except Exception:

            return []

        reviews = []

        for video in search.get("items", []):

            video_id = video["id"]["videoId"]

            text = None

            try:

                transcript = self.transcript_api.fetch(video_id)

                text = " ".join([chunk.text for chunk in transcript])

            except Exception:

                try:

                    comments = self.youtube.commentThreads().list(

                        part="snippet",

                        videoId=video_id,

                        maxResults=20

                    ).execute()

                    text = " ".join(
                        c["snippet"]["topLevelComment"]["snippet"]["textDisplay"]
                        for c in comments["items"]
                    )

                except Exception:

                    continue

            if not self._is_valid_review(text):
                continue

            reviews.append(

                NormalizedReview(

                    id=str(uuid.uuid4()),

                    product_id=product_id,
                    source_platform="youtube",

                    source_tier=SourceTier.VIDEO,

                    source_url=f"https://youtube.com/watch?v={video_id}",

                    body=text[:3000],

                    rating=await self._infer_rating(text)
                )
            )

        print("[ReviewAgg] YouTube:", len(reviews))

        return reviews

    # ─────────────────────────────────────────────

    def _is_valid_review(self, text):

        if not text:
            return False

        if len(text.split()) < 8:
            return False

        return True

    def _infer_rating_sync(self, text):
        """Synchronous sentiment analysis — must be wrapped in executor when called from async context."""
        result = self.sentiment(text[:512])[0]
        return 4.5 if result["label"] == "POSITIVE" else 2.0

    async def _infer_rating(self, text):
        """Async wrapper that runs sentiment analysis in thread executor to not block event loop."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._infer_rating_sync, text)