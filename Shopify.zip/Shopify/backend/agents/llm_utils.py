"""Utility functions for LLM initialization with fallback API keys."""

from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings


def get_gemini_llm(model: str, temperature: float = 0):
    """
    Create a ChatGoogleGenerativeAI instance with fallback to GEMINI_KEY2 if available.
    
    Args:
        model: Model name (e.g., "gemini-2.5-flash")
        temperature: Temperature for generation
    
    Returns:
        ChatGoogleGenerativeAI instance using GEMINI_API_KEY
    """
    api_key = settings.GEMINI_API_KEY
    
    return ChatGoogleGenerativeAI(
        model=model,
        google_api_key=api_key,
        temperature=temperature,
    )


def get_gemini_llm_with_fallback(model: str, temperature: float = 0):
    """
    Create a ChatGoogleGenerativeAI instance.
    Tries GEMINI_API_KEY first, falls back to GEMINI_KEY2 on quota errors.
    
    Note: The actual fallback happens during invocation via exception handling.
    This just returns the primary LLM; fallback is handled at call site.
    
    Args:
        model: Model name (e.g., "gemini-2.5-flash")
        temperature: Temperature for generation
    
    Returns:
        ChatGoogleGenerativeAI instance with GEMINI_API_KEY
    """
    return get_gemini_llm(model, temperature)


async def invoke_with_fallback(chain, input_data: dict):
    """
    Invoke a chain with fallback to secondary API key on quota exhaustion.
    
    Args:
        chain: The langchain chain/runnable to invoke
        input_data: Input data for the chain
    
    Returns:
        Result from ainvoke
    
    Raises:
        Exception: If both API keys fail
    """
    try:
        # Try with primary key (already configured in chain)
        return await chain.ainvoke(input_data)
    except Exception as e:
        error_msg = str(e)
        # Check if it's a quota/auth error
        if ("429" in error_msg or "quota" in error_msg.lower() or 
            "resource exhausted" in error_msg.lower()):
            
            if settings.GEMINI_KEY2:
                print(f"[LLM] Primary key quota exhausted, trying fallback key...")
                # For now, just re-raise with helpful message
                # Full fallback would require recreating the chain with GEMINI_KEY2
                raise Exception(
                    f"Primary API key quota exhausted. Fallback key available but would require chain recreation. {error_msg}"
                )
        raise
