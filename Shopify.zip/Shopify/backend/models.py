from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


# ── Product ────────────────────────────────────────────────────────────────────

class Product(BaseModel):
    asin: Optional[str] = None
    serpapi_link: Optional[str] = None
    id: str
    name: str
    brand: str
    price: float
    original_price: Optional[float] = None
    currency: str = "INR"
    platform: str
    url: str
    image_url: Optional[str] = None
    rating: Optional[float] = None
    review_count: Optional[int] = None
    source: str = "google_shopping"


# ── Review ─────────────────────────────────────────────────────────────────────

class SourceTier(str, Enum):
    ECOMMERCE = "ecommerce"       # Amazon, Flipkart
    DEDICATED = "dedicated"       # GSMArena, Rtings
    COMMUNITY = "community"       # Reddit, forums
    VIDEO     = "video"           # YouTube
    BLOG      = "blog"            # Affiliate blogs


class NormalizedReview(BaseModel):
    id: str
    product_id: str
    source_platform: str                  # "amazon", "reddit", "youtube"
    source_tier: SourceTier
    source_url: str
    reviewer_id: Optional[str] = None
    reviewer_metadata: Dict[str, Any] = {}   # verified_purchase, karma, account_age_days
    review_date: Optional[str] = None        # ISO string
    rating: Optional[float] = None           # Normalized 1–5
    title: Optional[str] = None
    body: str
    language: str = "en"
    affiliate_disclosure: bool = False
    helpful_votes: Optional[int] = None
    source: str = ""


# ── LangGraph Shared State ─────────────────────────────────────────────────────
# This is the single object that flows through all agents in the pipeline.

class ShoppingState(BaseModel):
    # ── Input
    user_query: str = ""
    user_id: Optional[str] = None
    conversation_history: List[Dict] = []

    # ── Agent 1 output
    parsed_intent: Optional[Dict] = None

    # ── Agent 2 output
    candidate_products: List[Dict] = []

    # ── Agent 3 output
    aggregated_reviews: Dict[str, List[Dict]] = {}   # product_id → [reviews]
    review_sources_used: Dict[str, List[str]] = {}   # product_id → [source names]

    # ── Agent 4 output (authenticity scoring — coming next)
    authenticity_scores: Dict[str, Dict] = {}

    # ── Agent 5 output (explainability — coming next)
    # Can be either a human-readable string or a structured dict produced by the explainability agent
    final_recommendation: Optional[Dict[str, Any]] = None
    top_products_ranked: List[Dict] = []

    # ── Control flow
    needs_clarification: bool = False
    clarification_question: Optional[str] = None
    error: Optional[str] = None
    current_agent: Optional[str] = None
    completed_agents: List[str] = []


# ── User Profile ───────────────────────────────────────────────────────────────

class UserProfile(BaseModel):
    user_id: str
    name: str
    age: int
    gender: str
    location: str
    budget_style: str
    preferred_categories: List[str]
    preferred_brands: List[str] = []
    avoided_brands: List[str] = []


# ── ParsedIntent ───────────────────────────────────────────────────────────────

class ParsedIntent(BaseModel):
    product_type: Optional[str] = None
    category: Optional[str] = None
    budget_min: Optional[float] = None
    budget_max: Optional[float] = None
    currency: str = "INR"
    budget_flexibility: str = "strict"
    use_case: Optional[str] = None
    requirements: List[str] = []
    deal_breakers: List[str] = []
    preferred_brands: List[str] = []
    inferred: List[str] = []
    needs_clarification: bool = False
    clarification_question: Optional[str] = None
    comparison_mode: bool = False
    raw_query: str = ""


# ── API Models ─────────────────────────────────────────────────────────────────

class SearchRequest(BaseModel):
    query: str
    user_id: Optional[str] = None
    user_profile: Optional[UserProfile] = None


class SearchResponse(BaseModel):
    success: bool
    stage: str
    state: Optional[ShoppingState] = None
    error: Optional[str] = None


class ParseQueryRequest(BaseModel):
    query: str
    user_id: Optional[str] = None


class ParseQueryResponse(BaseModel):
    success: bool
    parsed_intent: Optional[ParsedIntent] = None
    error: Optional[str] = None


class DiscoverProductsRequest(BaseModel):
    parsed_intent: ParsedIntent


class DiscoverProductsResponse(BaseModel):
    success: bool
    products: List[Product] = []
    query_used: Optional[str] = None
    error: Optional[str] = None


class SaveProfileRequest(BaseModel):
    profile: UserProfile


class SaveProfileResponse(BaseModel):
    success: bool
    message: str